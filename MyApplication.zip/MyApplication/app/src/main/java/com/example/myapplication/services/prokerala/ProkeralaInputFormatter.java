package com.example.myapplication.services.prokerala;


import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.matchmaking.table.InputMatchmaking;

public class ProkeralaInputFormatter {
    public InputMatchmaking getInputMatchmaking(InputBirthDetails bride, InputBirthDetails bridegroom) {

        //dob
        String brideDob = bride.getYear() + "-" + bride.getMonth() + "-" + bride.getDay() + "T" + bride.getHour() + ":" + bride.getMin() + ":22Z";
        String bridegroomDob = bridegroom.getYear() + "-" + bridegroom.getMonth() + "-" + bridegroom.getDay() + "T" + bridegroom.getHour() + ":" + bridegroom.getMin() + ":22Z";

        //coordinate
        String brideCo = bride.getLat() + "," + bride.getLon();
        String bridegroomCo = bridegroom.getLat() + "," + bridegroom.getLon();

        InputMatchmaking inputMatchmaking = new InputMatchmaking();

        inputMatchmaking.setAyanamsa("1");
        inputMatchmaking.setBrideDob(brideDob);
        inputMatchmaking.setBridegroomDob(bridegroomDob);
        inputMatchmaking.setBrideCoordinates(brideCo);
        inputMatchmaking.setBridegroomCoordinates(bridegroomCo);
        inputMatchmaking.setUserid(1);

        return inputMatchmaking;

    }
}
