
package com.example.myapplication.beans.matchmaking.table;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OutputMatchMaking {

    @SerializedName("match_status")
    @Expose
    private Integer matchStatus;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("varna")
    @Expose
    private Varna varna;
    @SerializedName("vasya")
    @Expose
    private Vasya vasya;
    @SerializedName("tara")
    @Expose
    private Tara tara;
    @SerializedName("yoni")
    @Expose
    private Yoni yoni;
    @SerializedName("graha_maitri")
    @Expose
    private GrahaMaitri grahaMaitri;
    @SerializedName("gana")
    @Expose
    private Gana gana;
    @SerializedName("bhakoot")
    @Expose
    private Bhakoot bhakoot;
    @SerializedName("nadi")
    @Expose
    private Nadi nadi;
    @SerializedName("total_point")
    @Expose
    private Double totalPoint;
    @SerializedName("sub_message")
    @Expose
    private List<String> subMessage = null;

    public Integer getMatchStatus() {
        return matchStatus;
    }

    public void setMatchStatus(Integer matchStatus) {
        this.matchStatus = matchStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Varna getVarna() {
        return varna;
    }

    public void setVarna(Varna varna) {
        this.varna = varna;
    }

    public Vasya getVasya() {
        return vasya;
    }

    public void setVasya(Vasya vasya) {
        this.vasya = vasya;
    }

    public Tara getTara() {
        return tara;
    }

    public void setTara(Tara tara) {
        this.tara = tara;
    }

    public Yoni getYoni() {
        return yoni;
    }

    public void setYoni(Yoni yoni) {
        this.yoni = yoni;
    }

    public GrahaMaitri getGrahaMaitri() {
        return grahaMaitri;
    }

    public void setGrahaMaitri(GrahaMaitri grahaMaitri) {
        this.grahaMaitri = grahaMaitri;
    }

    public Gana getGana() {
        return gana;
    }

    public void setGana(Gana gana) {
        this.gana = gana;
    }

    public Bhakoot getBhakoot() {
        return bhakoot;
    }

    public void setBhakoot(Bhakoot bhakoot) {
        this.bhakoot = bhakoot;
    }

    public Nadi getNadi() {
        return nadi;
    }

    public void setNadi(Nadi nadi) {
        this.nadi = nadi;
    }

    public Double getTotalPoint() {
        return totalPoint;
    }

    public void setTotalPoint(Double totalPoint) {
        this.totalPoint = totalPoint;
    }

    public List<String> getSubMessage() {
        return subMessage;
    }

    public void setSubMessage(List<String> subMessage) {
        this.subMessage = subMessage;
    }

    @Override
    public String toString() {
        return "OutputMatchMaking [matchStatus=" + matchStatus + ", message=" + message + ", varna=" + varna
                + ", vasya=" + vasya + ", tara=" + tara + ", yoni=" + yoni + ", grahaMaitri=" + grahaMaitri + ", gana="
                + gana + ", bhakoot=" + bhakoot + ", nadi=" + nadi + ", totalPoint=" + totalPoint + ", subMessage="
                + subMessage + "]";
    }


}
