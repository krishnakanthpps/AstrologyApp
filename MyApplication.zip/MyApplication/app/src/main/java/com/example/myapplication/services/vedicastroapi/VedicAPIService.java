package com.example.myapplication.services.vedicastroapi;



import com.example.myapplication.Kalsarp;
import com.example.myapplication.Papasamayam;
import com.example.myapplication.beans.dosh.kaalsarp.KaalSarp;
import com.example.myapplication.beans.dosh.mangal.MangalDosh;
import com.example.myapplication.beans.dosh.papasamaya.Papasamaya;
import com.example.myapplication.beans.dosh.pitra.PitraDosh;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface VedicAPIService {
    @GET("dosha/kaalsarpdosh")
    Call<KaalSarp> getKaalSarpDosh(
            @Query("dob") String dob,
            @Query("tob") String tob,
            @Query("lat") Double lat,
            @Query("lon") Double lon,
            @Query("tz") Double tz,
            @Query("api_key") String api_key
    );

    @GET("dosha/mangaldosh")
    Call<MangalDosh> getMangalDosh(
            @Query("dob") String dob,
            @Query("tob") String tob,
            @Query("lat") Double lat,
            @Query("lon") Double lon,
            @Query("tz") Double tz,
            @Query("api_key") String api_key
    );

    @GET("dosha/papasamaya")
    Call<Papasamaya> getPapasamayaDosh(
            @Query("dob") String dob,
            @Query("tob") String tob,
            @Query("lat") Double lat,
            @Query("lon") Double lon,
            @Query("tz") Double tz,
            @Query("api_key") String api_key
    );

    @GET("dosha/pitradosh")
    Call<PitraDosh> getPitraDosh(
            @Query("dob") String dob,
            @Query("tob") String tob,
            @Query("lat") Double lat,
            @Query("lon") Double lon,
            @Query("tz") Double tz,
            @Query("api_key") String api_key
    );

}
