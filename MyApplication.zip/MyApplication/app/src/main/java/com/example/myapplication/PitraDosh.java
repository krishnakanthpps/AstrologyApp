package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.dosh.DoshInput;
import com.example.myapplication.services.vedicastroapi.VedicAPIService;
import com.example.myapplication.services.vedicastroapi.VedicApiRetrofitInstance;
import com.example.myapplication.services.vedicastroapi.VedicInputFormatter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PitraDosh extends AppCompatActivity {
    TextView tv_pitraReport, tv_isPitraDoshPR ,tv_doshPR;

    DoshInput input;
    InputBirthDetails inputBirthDetails;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pitra_dosh);


        //bind view
        bindView();

        //input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        VedicInputFormatter formatter = new VedicInputFormatter();
        input = formatter.getVedicInput(inputBirthDetails);

        getPitraDosh();


    }

    public void bindView() {

        tv_pitraReport = findViewById(R.id.tv_pitraReport);
        // tv_doshPR = findViewById(R.id.tv_doshPresent);
    }

    public void getPitraDosh() {

        VedicAPIService apiService = VedicApiRetrofitInstance.getApiService();
        final Call<com.example.myapplication.beans.dosh.pitra.PitraDosh> call1 = apiService.getPitraDosh(input.getDob()
                , input.getTob(), input.getLat(), input.getLon(), input.getTz(), input.getApiKey()
        );
        call1.enqueue(new Callback<com.example.myapplication.beans.dosh.pitra.PitraDosh>() {
            @Override
            public void onResponse(Call<com.example.myapplication.beans.dosh.pitra.PitraDosh> call, Response<com.example.myapplication.beans.dosh.pitra.PitraDosh> response) {
                if (response.body().getStatus() == 200) {
                    com.example.myapplication.beans.dosh.pitra.PitraDosh pitraDosh = (response.body());
                    Log.d("MangalDosh", pitraDosh.toString());

                    String preset = pitraDosh.getResponse().getIsDoshaPresent().toString();
                    String report = pitraDosh.getResponse().getBotResponse();



                    tv_pitraReport.setText(report);

                    if(preset.equals("false")){
                        tv_pitraReport.setBackgroundColor(Color.GREEN);
                    }else {
                        tv_pitraReport.setBackgroundColor(Color.RED);
                    }


                }

            }

            @Override
            public void onFailure(Call<com.example.myapplication.beans.dosh.pitra.PitraDosh> call, Throwable t) {
                Log.d("MangalDosh Failure", t.getMessage());

            }
        });


    }
}
