package com.example.myapplication.beans.birthdetails;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InputBirthDetails {

    @SerializedName("year")
    @Expose
    private Integer year;
    @SerializedName("month")
    @Expose
    private Integer month;
    @SerializedName("day")
    @Expose
    private Integer day;
    @SerializedName("hour")
    @Expose
    private Integer hour;
    @SerializedName("min")
    @Expose
    private Integer min;
    @SerializedName("lat")
    @Expose
    private Double lat;
    @SerializedName("lon")
    @Expose
    private Double lon;
    @SerializedName("tzone")
    @Expose
    private Double tzone;

    public InputBirthDetails(){}

    public InputBirthDetails(Integer year, Integer month, Integer day, Integer hour, Integer min, Double lat, Double lon, Double tzone) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.min = min;
        this.lat = lat;
        this.lon = lon;
        this.tzone = tzone;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public Double getTzone() {
        return tzone;
    }

    public void setTzone(Double tzone) {
        this.tzone = tzone;
    }

    @Override
    public String toString() {
        return "InputBirthDetails{" +
                "year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", lat=" + lat +
                ", lon=" + lon +
                ", tzone=" + tzone +
                '}';
    }
}