package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.dosh.DoshInput;
import com.example.myapplication.services.vedicastroapi.VedicAPIService;
import com.example.myapplication.services.vedicastroapi.VedicApiRetrofitInstance;
import com.example.myapplication.services.vedicastroapi.VedicInputFormatter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MangalDosh extends AppCompatActivity {

    TextView tv_mangalScore, tv_mangalReport, tv_mangalDoshPR, tv_mangalRahu, tv_mangalSaturn, tv_mangalMoon;

    static DoshInput input;
    static InputBirthDetails inputBirthDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mangal_dosh);

        bindView();

        //input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        VedicInputFormatter formatter = new VedicInputFormatter();
        input = formatter.getVedicInput(inputBirthDetails);


        //getMangalDosh data
        getMangalDosh();

    }

    public void bindView() {
        tv_mangalSaturn = findViewById(R.id.tv_mangalSaturn);
        tv_mangalRahu = findViewById(R.id.tv_mangalRahu);
        tv_mangalDoshPR = findViewById(R.id.tv_mangalDoshPR);
        tv_mangalReport = findViewById(R.id.tv_mangalReport);
        tv_mangalScore = findViewById(R.id.tv_mangalScore);
        tv_mangalMoon = findViewById(R.id.tv_mangalMoon);

    }

    public void getMangalDosh() {

        VedicAPIService apiService = VedicApiRetrofitInstance.getApiService();
        final Call<com.example.myapplication.beans.dosh.mangal.MangalDosh> call1 = apiService.getMangalDosh(input.getDob()
                , input.getTob(), input.getLat(), input.getLon(), input.getTz(), input.getApiKey()
        );
        call1.enqueue(new Callback<com.example.myapplication.beans.dosh.mangal.MangalDosh>() {
            @Override
            public void onResponse(Call<com.example.myapplication.beans.dosh.mangal.MangalDosh> call, Response<com.example.myapplication.beans.dosh.mangal.MangalDosh> response) {
                if (response.body().getStatus() == 200) {
                    com.example.myapplication.beans.dosh.mangal.MangalDosh mangalDosh = (response.body());
                    Log.d("MangalDosh", mangalDosh.toString());

                    //TO-DO with recycler view

//                    String mangalSaturn = mangalDosh.getResponse().getFactors().getSaturn();
//                    String mangalRahu = mangalDosh.getResponse().getFactors().getRahu();
//                    String mangalMoon = mangalDosh.getResponse().getFactors().getMoon();
                    String mangalDoshPR = mangalDosh.getResponse().getIsDoshaPresent().toString();
                    String mangalScore = mangalDosh.getResponse().getScore().toString();
                    String mangalReport = mangalDosh.getResponse().getBotResponse();

                    tv_mangalSaturn.setVisibility(View.INVISIBLE);
                    tv_mangalRahu.setVisibility(View.INVISIBLE);
                    tv_mangalMoon.setVisibility(View.INVISIBLE);

                    tv_mangalDoshPR.setText(mangalDoshPR);
                    tv_mangalReport.setText(mangalReport);
                    tv_mangalScore.setText(mangalScore);


                }

            }

            @Override
            public void onFailure(Call<com.example.myapplication.beans.dosh.mangal.MangalDosh> call, Throwable t) {
                Log.d("MangalDosh Failure", t.getMessage());

            }
        });

    }
}
