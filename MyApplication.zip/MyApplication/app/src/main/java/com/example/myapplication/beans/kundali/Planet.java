package com.example.myapplication.beans.kundali;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Planet {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("is_reverse")
    @Expose
    private Boolean isReverse;
    @SerializedName("position")
    @Expose
    private Integer position;
    @SerializedName("degree")
    @Expose
    private String degree;
    @SerializedName("rasi")
    @Expose
    private String rasi;
    @SerializedName("rasi_lord")
    @Expose
    private String rasiLord;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Boolean getIsReverse() {
        return isReverse;
    }

    public void setIsReverse(Boolean isReverse) {
        this.isReverse = isReverse;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getRasi() {
        return rasi;
    }

    public void setRasi(String rasi) {
        this.rasi = rasi;
    }

    public String getRasiLord() {
        return rasiLord;
    }

    public void setRasiLord(String rasiLord) {
        this.rasiLord = rasiLord;
    }

    @Override
    public String toString() {
        return "Planet [id=" + id + ", name=" + name + ", longitude=" + longitude + ", isReverse=" + isReverse
                + ", position=" + position + ", degree=" + degree + ", rasi=" + rasi + ", rasiLord=" + rasiLord + "]";
    }


}