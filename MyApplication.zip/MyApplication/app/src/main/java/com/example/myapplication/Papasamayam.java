package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.dosh.DoshInput;
import com.example.myapplication.beans.dosh.papasamaya.Papasamaya;
import com.example.myapplication.services.vedicastroapi.VedicAPIService;
import com.example.myapplication.services.vedicastroapi.VedicApiRetrofitInstance;
import com.example.myapplication.services.vedicastroapi.VedicInputFormatter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Papasamayam extends AppCompatActivity {
    TextView tv_marsPapa, tv_saturnPapa, tv_sunPapa, tv_rahuPapa;

    DoshInput input;
    InputBirthDetails inputBirthDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_papasamayam);


        //bind view
        bindView();

        //input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        VedicInputFormatter formatter = new VedicInputFormatter();
        input = formatter.getVedicInput(inputBirthDetails);

        // get data

        getPapasamayaDosh();


    }

    public void bindView() {
        tv_marsPapa = findViewById(R.id.tv_marsPapa);
        tv_saturnPapa = findViewById(R.id.tv_saturnPapa);
        tv_sunPapa = findViewById(R.id.tv_sunPapa);
        tv_rahuPapa = findViewById(R.id.tv_rahuPapa);


    }

    public void getPapasamayaDosh() {

        VedicAPIService apiService = VedicApiRetrofitInstance.getApiService();
        final Call<Papasamaya> call1 = apiService.getPapasamayaDosh(input.getDob()
                , input.getTob(), input.getLat(), input.getLon(), input.getTz(), input.getApiKey()
        );
        call1.enqueue(new Callback<Papasamaya>() {
            @Override
            public void onResponse(Call<Papasamaya> call, Response<Papasamaya> response) {
                if (response.body().getStatus() == 200) {
                    Papasamaya papasamaya = (response.body());
                    Log.d("Papasamaya", papasamaya.toString());

                    tv_marsPapa.setText(papasamaya.getResponse().getMarsPapa().toString());
                    tv_saturnPapa.setText(papasamaya.getResponse().getSaturnPapa().toString());
                    tv_sunPapa.setText(papasamaya.getResponse().getSunPapa().toString());
                    tv_rahuPapa.setText(papasamaya.getResponse().getRahuPapa().toString());
                }

            }

            @Override
            public void onFailure(Call<Papasamaya> call, Throwable t) {
                Log.d("Papasamaya Failure", t.getMessage());

            }
        });


    }
}
