package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DoshMain extends AppCompatActivity {

    Button btn_kalsarp,btn_mangal,btn_pitra,btn_papa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dosh_main);

        btn_kalsarp = (Button)findViewById(R.id.btn_kalsarp);
        btn_mangal =(Button)findViewById(R.id.btn_mangalDosh);
        btn_pitra = (Button)findViewById(R.id.btn_pitraDosh);
        btn_papa = (Button)findViewById(R.id.btn_papasamayam);


        btn_kalsarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kalIntent = new Intent(DoshMain.this,KundaliCheckActivity.class);
                startActivity(kalIntent);
            }
        });

        btn_mangal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mangalIntent = new Intent(DoshMain.this,KundaliCheckActivity.class);
                startActivity(mangalIntent);
            }
        });

        btn_pitra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pitraIntent = new Intent(DoshMain.this,KundaliCheckActivity.class);
                startActivity(pitraIntent);
            }
        });

        btn_papa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent papaIntent = new Intent(DoshMain.this,KundaliCheckActivity.class);
                startActivity(papaIntent);
            }
        });



    }
}
