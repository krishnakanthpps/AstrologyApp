
package com.example.myapplication.beans.dosh.kaalsarp;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("is_dosha_present")
    @Expose
    private Boolean isDoshaPresent;
    @SerializedName("bot_response")
    @Expose
    private String botResponse;
    @SerializedName("kalatra_by_saturn")
    @Expose
    private Boolean kalatraBySaturn;
    @SerializedName("kalatra_by_rahuketu")
    @Expose
    private Boolean kalatraByRahuketu;

    public Boolean getIsDoshaPresent() {
        return isDoshaPresent;
    }

    public void setIsDoshaPresent(Boolean isDoshaPresent) {
        this.isDoshaPresent = isDoshaPresent;
    }

    public String getBotResponse() {
        return botResponse;
    }

    public void setBotResponse(String botResponse) {
        this.botResponse = botResponse;
    }

    public Boolean getKalatraBySaturn() {
        return kalatraBySaturn;
    }

    public void setKalatraBySaturn(Boolean kalatraBySaturn) {
        this.kalatraBySaturn = kalatraBySaturn;
    }

    public Boolean getKalatraByRahuketu() {
        return kalatraByRahuketu;
    }

    public void setKalatraByRahuketu(Boolean kalatraByRahuketu) {
        this.kalatraByRahuketu = kalatraByRahuketu;
    }

    @Override
    public String toString() {
        return "Response{" +
                "isDoshaPresent=" + isDoshaPresent +
                ", botResponse='" + botResponse + '\'' +
                ", kalatraBySaturn=" + kalatraBySaturn +
                ", kalatraByRahuketu=" + kalatraByRahuketu +
                '}';
    }
}
