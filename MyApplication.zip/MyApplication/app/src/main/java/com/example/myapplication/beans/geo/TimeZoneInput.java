package com.example.myapplication.beans.geo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TimeZoneInput {

    @SerializedName("country_code")
    @Expose
    private String countryCode;
    @SerializedName("isDst")
    @Expose
    private String isDst;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getIsDst() {
        return isDst;
    }

    public void setIsDst(String isDst) {
        this.isDst = isDst;
    }

}