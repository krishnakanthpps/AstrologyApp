package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Muhurat extends AppCompatActivity {

    Button btn_vivah,btn_mundan,btn_grih,btn_nam,btn_lunar,btn_solar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muhurat);

        btn_vivah = (Button)findViewById(R.id.btn_vivahMuhurat);
        btn_mundan = (Button)findViewById(R.id.btn_mundanMuhurat);
        btn_grih = (Button)findViewById(R.id.btn_grihMuhurat);
        btn_nam = (Button)findViewById(R.id.btn_namMuhurat);
        btn_lunar = (Button)findViewById(R.id.btn_lunarEclipse);
        btn_solar = (Button)findViewById(R.id.btn_solarEclipse);


        btn_vivah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent vivahIntent = new Intent(Muhurat.this,VivahMuhurat.class);
                startActivity(vivahIntent);
            }
        });

        btn_mundan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mundanIntent = new Intent(Muhurat.this,MundanMuhurat.class);
                startActivity(mundanIntent);
            }
        });
        btn_grih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent grihIntent = new Intent(Muhurat.this,GrihMuhurat.class);
                startActivity(grihIntent);
            }
        });
        btn_nam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent namIntent = new Intent(Muhurat.this,NamMuhurat.class);
                startActivity(namIntent);
            }
        });
        btn_solar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent solarIntent = new Intent(Muhurat.this,SolarEclipse.class);
                startActivity(solarIntent);
            }
        });
        btn_lunar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lunarIntent = new Intent(Muhurat.this,LunarEclipse.class);
                startActivity(lunarIntent);
            }
        });
    }
}
