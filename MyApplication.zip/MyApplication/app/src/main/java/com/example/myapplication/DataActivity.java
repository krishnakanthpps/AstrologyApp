package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Build;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.Toolbar;
import android.widget.ViewAnimator;

import com.google.android.material.tabs.TabLayout;

public class DataActivity extends AppCompatActivity {

    private Toolbar toolBar;
    private TabLayout tableLayout;
    private ViewPager viewPager;



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        toolBar = (Toolbar)findViewById(R.id.mytoolBar);
        tableLayout = (TabLayout)findViewById(R.id.tablayout);
        viewPager = (ViewPager)findViewById(R.id.myviewPager);


        setActionBar(toolBar);
        setViewPager(viewPager);

        tableLayout.setupWithViewPager(viewPager);
        


    }

    private  void setViewPager(ViewPager viewPager){
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter .addFragment(new Tab1Fragment(),"Tab 1");
        viewPagerAdapter .addFragment(new Tab2Fragment(),"Tab 2");
        viewPagerAdapter .addFragment(new Tab3Fragment(),"Tab 3");
        viewPager.setAdapter(viewPagerAdapter);
    }


}
