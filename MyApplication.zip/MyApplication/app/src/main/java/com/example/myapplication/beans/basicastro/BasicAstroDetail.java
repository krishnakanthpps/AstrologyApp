package com.example.myapplication.beans.basicastro;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BasicAstroDetail {

@SerializedName("Varna")
@Expose
private String varna;
@SerializedName("Vashya")
@Expose
private String vashya;
@SerializedName("Yoni")
@Expose
private String yoni;
@SerializedName("sign_lord")
@Expose
private Integer signLord;
@SerializedName("sign")
@Expose
private String sign;
@SerializedName("Naksahtra")
@Expose
private String naksahtra;
@SerializedName("naksahtra_lord")
@Expose
private String naksahtraLord;
@SerializedName("nakshatra_charan")
@Expose
private Integer nakshatraCharan;
@SerializedName("name_alphabet")
@Expose
private String nameAlphabet;

public String getVarna() {
return varna;
}

public void setVarna(String varna) {
this.varna = varna;
}

public String getVashya() {
return vashya;
}

public void setVashya(String vashya) {
this.vashya = vashya;
}

public String getYoni() {
return yoni;
}

public void setYoni(String yoni) {
this.yoni = yoni;
}

public Integer getSignLord() {
return signLord;
}

public void setSignLord(Integer signLord) {
this.signLord = signLord;
}

public String getSign() {
return sign;
}

public void setSign(String sign) {
this.sign = sign;
}

public String getNaksahtra() {
return naksahtra;
}

public void setNaksahtra(String naksahtra) {
this.naksahtra = naksahtra;
}

public String getNaksahtraLord() {
return naksahtraLord;
}

public void setNaksahtraLord(String naksahtraLord) {
this.naksahtraLord = naksahtraLord;
}

public Integer getNakshatraCharan() {
return nakshatraCharan;
}

public void setNakshatraCharan(Integer nakshatraCharan) {
this.nakshatraCharan = nakshatraCharan;
}

public String getNameAlphabet() {
return nameAlphabet;
}

public void setNameAlphabet(String nameAlphabet) {
this.nameAlphabet = nameAlphabet;
}

    @Override
    public String toString() {
        return "AstroDetail{" +
                "varna='" + varna + '\'' +
                ", vashya='" + vashya + '\'' +
                ", yoni='" + yoni + '\'' +
                ", signLord=" + signLord +
                ", sign='" + sign + '\'' +
                ", naksahtra='" + naksahtra + '\'' +
                ", naksahtraLord='" + naksahtraLord + '\'' +
                ", nakshatraCharan=" + nakshatraCharan +
                ", nameAlphabet='" + nameAlphabet + '\'' +
                '}';
    }
}