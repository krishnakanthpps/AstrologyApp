package com.example.myapplication;

import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class MainMuhurat extends Fragment {

    private MainMuhuratViewModel mViewModel;
    Button btn_vivahMuhurat,btn_mundanMuhurat,btn_lunarEclipse,btn_solarEclipse,btn_namkaranMuhurat,btn_grihMuhurat;

    public static MainMuhurat newInstance() {
        return new MainMuhurat();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.main_muhurat_fragment, container, false);

        btn_vivahMuhurat = (Button)view.findViewById(R.id.btn_vivahMuhurat);
        btn_vivahMuhurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent vivahIntent = new Intent(getActivity(),VivahMuhurat.class);
                startActivity(vivahIntent);
            }
        });



        btn_mundanMuhurat = (Button)view.findViewById(R.id.btn_mundanMuhurat);
        btn_mundanMuhurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mundanIntent = new Intent(getActivity(),MundanMuhurat.class);
                startActivity(mundanIntent);
            }
        });


        btn_lunarEclipse = (Button)view.findViewById(R.id.btn_lunarEclipse);
        btn_lunarEclipse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lunarIntent = new Intent(getActivity(),LunarEclipse.class);
                startActivity(lunarIntent);
            }
        });


        btn_solarEclipse = (Button)view.findViewById(R.id.btn_solarEclipse);
        btn_solarEclipse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent solarIntent = new Intent(getActivity(),SolarEclipse.class);
                startActivity(solarIntent);
            }
        });


        btn_namkaranMuhurat = (Button)view.findViewById(R.id.btn_namMuhurat);
        btn_namkaranMuhurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent namIntent = new Intent(getActivity(),NamMuhurat.class);
                startActivity(namIntent);
            }
        });


        btn_grihMuhurat = (Button)view.findViewById(R.id.btn_grihMuhurat);
        btn_grihMuhurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent grihIntent = new Intent(getActivity(),VivahMuhurat.class);
                startActivity(grihIntent);
            }
        });




        return view;



    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainMuhuratViewModel.class);
        // TODO: Use the ViewModel
    }

}
