package com.example.myapplication;

import androidx.lifecycle.ViewModel;

public class MainKMViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
