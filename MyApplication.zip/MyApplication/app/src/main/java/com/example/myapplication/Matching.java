package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.Geoname;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.beans.geo.TimeZoneInput;
import com.example.myapplication.beans.geo.TimeZoneOutput;
import com.example.myapplication.services.astroapi.AstroAPIService;
import com.example.myapplication.services.astroapi.AstroAPIServicesImpl;
import com.example.myapplication.services.astroapi.AstroApiRetrofitInstance;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Matching extends AppCompatActivity {
    boolean femaleFlag = false;
    boolean maleFlag= false;

    Button btn_show;
    TextView maleName,femaleName,maleDate,femaleDate,maleTime,femaleTime;
    AutoCompleteTextView maleLocation,femaleLocation;
    SimpleDateFormat timeformat;
    Calendar calendar ;
    static AstroAPIServicesImpl serv = new AstroAPIServicesImpl();
    private DatePickerDialog.OnDateSetListener dateSetListenerMale ,dateSetListenerFemale ;
    private static final String TAG = "Matching";


    static Geoname geoname;
    static boolean flag;
    static GeoDetails geoDetails;
    private Handler handler;
    InputBirthDetails maleInput;
    InputBirthDetails femaleInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matching);

        btn_show = (Button)findViewById(R.id.btn_showMatch);
        maleName = (TextView)findViewById(R.id.tv_maleName);
        femaleName = (TextView)findViewById(R.id.tv_femaleName);
        maleDate = (TextView)findViewById(R.id.tv_maleDate);
        femaleDate = (TextView)findViewById(R.id.tv_femaleDate);
        maleTime = (TextView)findViewById(R.id.tv_maleTime);
        femaleTime = (TextView)findViewById(R.id.tv_femaleTime);
        maleLocation = (AutoCompleteTextView)findViewById(R.id.et_maleLocation);
        femaleLocation = (AutoCompleteTextView)findViewById(R.id.et_femaleLocation);
        calendar = Calendar.getInstance();
        timeformat = new SimpleDateFormat("HH:mm");


        //create input object
        maleInput = new InputBirthDetails();
        femaleInput = new InputBirthDetails();


//        male
        maleTime.setText(timeformat.format(calendar.getTime()));
        maleDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));
//female
        femaleTime.setText(timeformat.format(calendar.getTime()));
        femaleDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));

        setTitle("Matching");

        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(Matching.this,MatchingData.class);
//                startActivity(i);
                // System.out.println("11111111"+maleName.getText().toString()+maleDate.getText().toString()+maleTime.getText().toString()+maleLocation.getText().toString().toString());
                //  System.out.println("11111111"+femaleName.getText().toString()+femaleDate.getText().toString()+femaleTime.getText().toString()+femaleLocation.getText().toString().toString());
                redirect();
            }
        });
//        male
        maleDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Matching.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListenerMale,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        dateSetListenerMale = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "-"+ day + "-" + year);
                String date = day + "-" + month + "-" + year;
                maleDate.setText(date);

                maleInput.setDay(day);
                maleInput.setYear(year);
                maleInput.setMonth(month);


            }
        };
        maleTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTimeMale();
            }
        });


//       female

        femaleDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Matching.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListenerFemale,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        dateSetListenerFemale = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "-"+ day + "-" + year);
                String date = day + "-" + month + "-" + year;
                femaleDate.setText(date);

                femaleInput.setDay(day);
                femaleInput.setYear(year);
                femaleInput.setMonth(month);
            }
        };
        femaleTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTimeFemale();
            }
        });


        //      Location male

        maleLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreDataMale("mumbai");
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreDataMale(maleLocation.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        //location female
        femaleLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreDataFemale("mumbai");
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreDataFemale(femaleLocation.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        femaleLocation.setOnItemClickListener(maleonItemClickListener);
        maleLocation.setOnItemClickListener(femaleonItemClickListener);
    }







//      button

    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);


            femaleInput.setHour(hourOfDay);
            femaleInput.setMin(minute);

            updateTimeFemale();

        }
    };
    TimePickerDialog.OnTimeSetListener t1 = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);


            maleInput.setHour(hourOfDay);
            maleInput.setMin(minute);

            updateTimeMale();
        }
    };


    public void updateTimeFemale() {

        femaleTime.setText(timeformat.format(calendar.getTime()));
    }
    public void updateTimeMale() {
        maleTime.setText(timeformat.format(calendar.getTime()));
    }

    private AdapterView.OnItemClickListener maleonItemClickListener =
            new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    InputPlace maleplace = new InputPlace();
                    maleplace.setPlace(maleLocation.getText().toString());
                    maleplace.setMaxRows(1);
                    getmalegeodetails(maleplace);
                }
            };
    private AdapterView.OnItemClickListener femaleonItemClickListener =
            new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    InputPlace femaleplace = new InputPlace();
                    femaleplace.setPlace(femaleLocation.getText().toString());
                    femaleplace.setMaxRows(1);
                    getfemalegeodetails(femaleplace);
                }
            };

    public void chooseTimeMale(){
        String time;
        new TimePickerDialog(this , t1 ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
        time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        maleTime.setText(time);

    }
    public void chooseTimeFemale(){
        String time;
        new TimePickerDialog(this , t ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
        time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        femaleTime.setText(time);
    }


    public void getStoreDataFemale(final String strin){
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails = serv.getgeodetails(in);
                flag = true;
            }
        }).start();
        if (flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(Matching.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));
            femaleLocation.setAdapter(adapteo);
        }
    }


    public void getStoreDataMale(final String strin) {
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails = serv.getgeodetails(in);
                flag = true;
            }
        }).start();
        if (flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(Matching.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));
            maleLocation.setAdapter(adapteo);
        }
    }

    public void getmalegeodetails(InputPlace iplace) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<GeoDetails> call1 = apiService.getGenomes(iplace);
        call1.enqueue(new Callback<GeoDetails>() {
            @Override
            public void onResponse(Call<GeoDetails> call, Response<GeoDetails> response) {
                if (response.isSuccessful()) {
                    GeoDetails geoDeatils = response.body();
                    List<Geoname> geonameList   = geoDeatils.getGeonames();
                    Geoname geoname = geonameList.get(0);
                    TimeZoneInput tzin = new TimeZoneInput();
                    tzin.setCountryCode(geoname.getTimezoneId());
                    tzin.setIsDst("true");
                    getmaleTimeZone(tzin);
                    maleInput.setLat(Double.parseDouble(geoname.getLatitude()));
                    maleInput.setLon(Double.parseDouble(geoname.getLongitude()));
                    System.out.println("-----------geode"+geoname);

                }

            }

            @Override
            public void onFailure(Call<GeoDetails> call, Throwable t) {
                System.out.println(t.getMessage());

            }
        });
    }
    public void getmaleTimeZone(TimeZoneInput tzi) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<TimeZoneOutput> call1 = apiService.getTimeZone(tzi);
        call1.enqueue(new Callback<TimeZoneOutput>() {
            @Override
            public void onResponse(Call<TimeZoneOutput> call, Response<TimeZoneOutput> response) {
                if (response.isSuccessful()) {
                    TimeZoneOutput tzout = response.body();
                    System.out.println(tzout);
                    maleInput.setTzone(tzout.getTimezone());
                    maleFlag = true;
                    redirect();
                }
            }
            @Override
            public void onFailure(Call<TimeZoneOutput> call, Throwable t) {
                System.err.println(t.getMessage());
            }
        });
    }
    public void getfemalegeodetails(InputPlace iplace) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<GeoDetails> call1 = apiService.getGenomes(iplace);
        call1.enqueue(new Callback<GeoDetails>() {
            @Override
            public void onResponse(Call<GeoDetails> call, Response<GeoDetails> response) {
                if (response.isSuccessful()) {
                    GeoDetails geoDeatils = response.body();
                    List<Geoname> geonameList   = geoDeatils.getGeonames();
                    Geoname geoname = geonameList.get(0);
                    TimeZoneInput tzin = new TimeZoneInput();
                    tzin.setCountryCode(geoname.getTimezoneId());
                    tzin.setIsDst("true");
                    getfemaleTimeZone(tzin);
                    femaleInput.setLat(Double.parseDouble(geoname.getLatitude()));
                    femaleInput.setLon(Double.parseDouble(geoname.getLongitude()));
                    System.out.println("female----------geode"+geoname);

                }

            }

            @Override
            public void onFailure(Call<GeoDetails> call, Throwable t) {
                System.out.println(t.getMessage());

            }
        });
    }
    public void getfemaleTimeZone(TimeZoneInput tzi) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<TimeZoneOutput> call1 = apiService.getTimeZone(tzi);
        call1.enqueue(new Callback<TimeZoneOutput>() {
            @Override
            public void onResponse(Call<TimeZoneOutput> call, Response<TimeZoneOutput> response) {
                if (response.isSuccessful()) {
                    TimeZoneOutput tzout = response.body();
                    System.out.println(tzout);
                    femaleInput.setTzone(tzout.getTimezone());

                    femaleFlag = true;
                    redirect();
                }
            }
            @Override
            public void onFailure(Call<TimeZoneOutput> call, Throwable t) {
                System.err.println(t.getMessage());
            }
        });
    }

    private void redirect() {

        System.out.println("**"+maleInput);
        System.out.println("**"+femaleInput);
        if(maleFlag && femaleFlag){
            Intent i = new Intent(Matching.this,MatchingData.class);
            i.putExtra("maleInput", maleInput);
            i.putExtra("femaleInput", femaleInput);
            startActivity(i);
        }


    }

}
