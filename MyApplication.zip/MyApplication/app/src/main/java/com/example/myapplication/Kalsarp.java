package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.dosh.DoshInput;
import com.example.myapplication.beans.dosh.kaalsarp.KaalSarp;
import com.example.myapplication.services.vedicastroapi.VedicAPIService;
import com.example.myapplication.services.vedicastroapi.VedicApiRetrofitInstance;
import com.example.myapplication.services.vedicastroapi.VedicInputFormatter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Kalsarp extends AppCompatActivity {
    TextView tv_kalataraRahuketu, tv_kalataraSaturn, tv_kalSarpReport, tv_isKalsarpPR, tv_mangalMoon;
    static DoshInput input;
    InputBirthDetails inputBirthDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kalsarp);
        bindView();

        //input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        VedicInputFormatter formatter = new VedicInputFormatter();
        input = formatter.getVedicInput(inputBirthDetails);

        //   input = new DoshInput("19/9/1996","11:27",11.27,83.01,5.5,"2966c315-103c-56b8-9242-8c956d37631f");

        //call methods
        getKaalsarpDosh();

    }

    public void bindView() {
        tv_kalataraRahuketu = findViewById(R.id.tv_kalataraRahuketu);
        tv_kalataraSaturn = findViewById(R.id.tv_kalataraSaturn);
        tv_kalSarpReport = findViewById(R.id.tv_kalSarpReport);
        tv_isKalsarpPR = findViewById(R.id.tv_isKalsarpPR);

    }

    public void getKaalsarpDosh() {
        VedicAPIService apiService = VedicApiRetrofitInstance.getApiService();
        final Call<KaalSarp> call1 = apiService.getKaalSarpDosh(input.getDob()
                , input.getTob(), input.getLat(), input.getLon(), input.getTz(), input.getApiKey()
        );
        call1.enqueue(new Callback<KaalSarp>() {
            @Override
            public void onResponse(Call<KaalSarp> call, Response<KaalSarp> response) {
                if (response.isSuccessful()) {
                    KaalSarp kaalSarp = (response.body());

                    String isKP = kaalSarp.getResponse().getIsDoshaPresent().toString();
                    String report = kaalSarp.getResponse().getBotResponse();
                    String rahuketu = kaalSarp.getResponse().getKalatraByRahuketu().toString();
                    String saturn = kaalSarp.getResponse().getKalatraBySaturn().toString();
                    tv_isKalsarpPR.setText(isKP);
                    tv_kalSarpReport.setText(report);
                    tv_kalataraRahuketu.setText(rahuketu);
                    tv_kalataraSaturn.setText(saturn);
                    //   tv_kalataraRahuketu.setText(kaalSarp.getResponse().toString());
                    Log.d("getKaalsarpDosh", kaalSarp.toString());
                    Log.d("getKaalsarpDosh", isKP);
                }

            }

            @Override
            public void onFailure(Call<KaalSarp> call, Throwable t) {
                Log.d("getKaalsarpDosh Failure", t.getMessage());

            }
        });
    }
}
