package com.example.myapplication;


import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.Geoname;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.beans.geo.TimeZoneInput;
import com.example.myapplication.beans.geo.TimeZoneOutput;
import com.example.myapplication.services.astroapi.AstroAPIService;
import com.example.myapplication.services.astroapi.AstroAPIServicesImpl;
import com.example.myapplication.services.astroapi.AstroApiRetrofitInstance;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateBirthDetail {

     InputBirthDetails inputBirthDetails = new InputBirthDetails();
    static AstroAPIServicesImpl serv = new AstroAPIServicesImpl();
    static Geoname geoname;
    static boolean flag1 = false;
    static boolean flag2 = false;

    public InputBirthDetails getInputBirthDetails(String date, String time, final String location) {

        System.out.println("create profile method" + date + " " + time + " " + location);


        // dd/mm/yyyy
        String[] dateArray = date.split("/");
        //day
        inputBirthDetails.setDay(Integer.parseInt(dateArray[0]));

        //month
        inputBirthDetails.setMonth(Integer.parseInt(dateArray[1]));

        //year
        inputBirthDetails.setYear(Integer.parseInt(dateArray[2]));

        //time

        String[] timeArray = time.split(":");
        //hour
        inputBirthDetails.setHour(Integer.parseInt(timeArray[0]));

        //min
        inputBirthDetails.setMin(Integer.parseInt(timeArray[1]));

         return inputBirthDetails;
    }

    public void getgeodetails(InputPlace iplace) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<GeoDetails> call1 = apiService.getGenomes(iplace);
        call1.enqueue(new Callback<GeoDetails>() {
            @Override
            public void onResponse(Call<GeoDetails> call, Response<GeoDetails> response) {
                if (response.isSuccessful()) {
                    GeoDetails geoDeatils = response.body();
                    flag1 = true;
                     List<Geoname> geonameList   = geoDeatils.getGeonames();
                    Geoname geoname = geonameList.get(0);
                    inputBirthDetails.setLat(Double.parseDouble(geoname.getLatitude()));
                    inputBirthDetails.setLon(Double.parseDouble(geoname.getLongitude()));

                }

            }

            @Override
            public void onFailure(Call<GeoDetails> call, Throwable t) {
                System.out.println(t.getMessage());

            }
        });
    }
    private static TimeZoneOutput tzout;

    public void getTimeZone(TimeZoneInput tzi) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<TimeZoneOutput> call1 = apiService.getTimeZone(tzi);
        call1.enqueue(new Callback<TimeZoneOutput>() {
            @Override
            public void onResponse(Call<TimeZoneOutput> call, Response<TimeZoneOutput> response) {
                if (response.isSuccessful()) {
                    tzout = response.body();
                    System.out.println(tzout);
                    flag2 = true;
                    inputBirthDetails.setTzone(tzout.getTimezone());
                }
            }
            @Override
            public void onFailure(Call<TimeZoneOutput> call, Throwable t) {
                System.err.println(t.getMessage());
            }
        });
    }
}