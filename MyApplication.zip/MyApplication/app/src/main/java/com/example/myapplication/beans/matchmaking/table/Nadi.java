
package com.example.myapplication.beans.matchmaking.table;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Nadi {

    @SerializedName("bride")
    @Expose
    private String bride;
    @SerializedName("bridegroom")
    @Expose
    private String bridegroom;
    @SerializedName("point")
    @Expose
    private Integer point;
    @SerializedName("message")
    @Expose
    private String message;

    public String getBride() {
        return bride;
    }

    public void setBride(String bride) {
        this.bride = bride;
    }

    public String getBridegroom() {
        return bridegroom;
    }

    public void setBridegroom(String bridegroom) {
        this.bridegroom = bridegroom;
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Nadi [bride=" + bride + ", bridegroom=" + bridegroom + ", point=" + point + ", message=" + message
                + "]";
    }


}
