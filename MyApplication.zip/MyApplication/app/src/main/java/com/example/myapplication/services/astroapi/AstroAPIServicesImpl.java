package com.example.myapplication.services.astroapi;

import com.example.myapplication.beans.basicastro.BasicAstroDetail;
import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.birthdetails.OutputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.beans.geo.TimeZoneInput;
import com.example.myapplication.beans.geo.TimeZoneOutput;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AstroAPIServicesImpl {
    static OutputBirthDetails outputBirthDetails;

    static boolean flag = false;

    public OutputBirthDetails birth() {
        outputBirthDetails = null;
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        InputBirthDetails eg = new InputBirthDetails(1992, 7, 22, 9, 21, 25.31668, 83.01042, 5.5);
        final Call<OutputBirthDetails> call1 = apiService.getBirthDetails(eg);
        call1.enqueue(new Callback<OutputBirthDetails>() {
            @Override
            public void onResponse(Call<OutputBirthDetails> call, Response<OutputBirthDetails> response) {
                if (response.isSuccessful()) {
                    outputBirthDetails = (response.body());
                    flag = true;
                }

            }

            @Override
            public void onFailure(Call<OutputBirthDetails> call, Throwable t) {
                flag = true;

            }
        });
        while (!flag) {
            System.out.print("");
        }
        flag = false;
        return outputBirthDetails;
    }


    //get GeoDetails
    private static GeoDetails geoDeatils;

    public GeoDetails getgeodetails(InputPlace iplace) {
        geoDeatils = null;
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<GeoDetails> call1 = apiService.getGenomes(iplace);
        call1.enqueue(new Callback<GeoDetails>() {
            @Override
            public void onResponse(Call<GeoDetails> call, Response<GeoDetails> response) {
                if (response.isSuccessful()) {
                    geoDeatils = response.body();
                    flag = true;
//                     geoDeatils  = out.getGeonames();
//                    Geoname geoname = geonameList.get(0);
//                    inputBirthDetails.setLat(Double.parseDouble(geoname.getLatitude()));
//                    inputBirthDetails.setLon(Double.parseDouble(geoname.getLongitude()));

                }

            }

            @Override
            public void onFailure(Call<GeoDetails> call, Throwable t) {
                //String s = response.body();
                flag = true;

            }
        });
        while (!flag) {
            System.out.print("");
        }
        flag = false;
        return geoDeatils;
    }

    //getTimeZone
    private static TimeZoneOutput tzout;

    public TimeZoneOutput getTimeZone(TimeZoneInput tzi) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<TimeZoneOutput> call1 = apiService.getTimeZone(tzi);
        call1.enqueue(new Callback<TimeZoneOutput>() {
            @Override
            public void onResponse(Call<TimeZoneOutput> call, Response<TimeZoneOutput> response) {
                if (response.isSuccessful()) {
                    tzout = response.body();
                    System.out.println(tzout);
                    flag = true;
//                    inputBirthDetails.setTzone(out.getTimezone());
                }

            }

            @Override
            public void onFailure(Call<TimeZoneOutput> call, Throwable t) {
                System.err.println(t.getMessage());
                flag = true;

            }
        });
        while (!flag) {
            System.out.print("");
        }
        flag = false;
        return tzout;

    }

    //basic astro
    static BasicAstroDetail astroDetail;

    public BasicAstroDetail getBasicAstroDetail(InputBirthDetails ip) {
        astroDetail = null;
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<BasicAstroDetail> call1 = apiService.getAstroDetail(ip);
        call1.enqueue(new Callback<BasicAstroDetail>() {
            @Override
            public void onResponse(Call<BasicAstroDetail> call, Response<BasicAstroDetail> response) {
                if (response.isSuccessful()) {
                    astroDetail = response.body();
//                    System.out.println(astroDetail);
                    flag = true;
//                    inputBirthDetails.setTzone(out.getTimezone());
                }

            }

            @Override
            public void onFailure(Call<BasicAstroDetail> call, Throwable t) {
//                System.err.println(t.getMessage());
                flag = true;

            }
        });
        while (!flag) {
            System.out.print("");
        }
        flag = false;
        return astroDetail;

    }


}
