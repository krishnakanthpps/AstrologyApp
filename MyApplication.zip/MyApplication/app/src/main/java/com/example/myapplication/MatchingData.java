package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.matchmaking.table.InputMatchmaking;
import com.example.myapplication.beans.matchmaking.table.OutputMatchMaking;
import com.example.myapplication.services.prokerala.ProkeralaAPIService;
import com.example.myapplication.services.prokerala.ProkeralaApiRetrofitInstance;
import com.example.myapplication.services.prokerala.ProkeralaInputFormatter;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MatchingData extends AppCompatActivity {
    TextView tv_points, tv_maleMangal, tv_femaleMangal;
    TextView tv_maitriObt, tv_yoniObt, tv_taraObt, tv_vashyaObt, tv_varnaObt, tv_nadiObt, tv_bhakatObt, tv_gunObt, tv_totalObt;
    TextView tv_gunReport;

    InputMatchmaking eg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matching_data);
        //bind view
        bindView();


        //input
        ProkeralaInputFormatter formatter = new ProkeralaInputFormatter();
        //enable on
        // eg = formatter.getInputMatchmaking(MatchMaking.bride, MatchMaking.bridegroom);

        //test
        InputBirthDetails maleInputs = (InputBirthDetails) getIntent().getSerializableExtra("maleInput");
        InputBirthDetails femaleInputs = (InputBirthDetails) getIntent().getSerializableExtra("femaleInput");

        eg = formatter.getInputMatchmaking(maleInputs,femaleInputs);
        System.out.println("----------" + eg);
        //get data
        getMatchingData();

    }

    public void bindView() {
        tv_points = findViewById(R.id.tv_points);
        tv_maleMangal = findViewById(R.id.tv_maleMangal);
        tv_femaleMangal = findViewById(R.id.tv_femaleMangal);

        tv_maitriObt = findViewById(R.id.tv_maitriObt);
        tv_yoniObt = findViewById(R.id.tv_yoniObt);
        tv_taraObt = findViewById(R.id.tv_taraObt);
        tv_vashyaObt = findViewById(R.id.tv_vashyaObt);
        tv_varnaObt = findViewById(R.id.tv_varnaObt);
        tv_nadiObt = findViewById(R.id.tv_nadiObt);
        tv_bhakatObt = findViewById(R.id.tv_bhakatObt);
        tv_gunObt = findViewById(R.id.tv_gunObt);
        tv_totalObt = findViewById(R.id.tv_totalObt);

        tv_gunReport = findViewById(R.id.tv_gunReport);


    }

    public void getMatchingData() {
        ProkeralaAPIService apiService = ProkeralaApiRetrofitInstance.getApiService();
        final Call<ResponseBody> call1 = apiService.getMatchingData(eg.getAyanamsa(), eg.getBrideDob(), eg.getBridegroomDob(),
                eg.getBrideCoordinates(), eg.getBridegroomCoordinates()
        );
        call1.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    try {
                        String str = (response.body().string());

                        JSONObject reqres = new JSONObject(str);
                        JSONObject res = (JSONObject) reqres.get("response");
                        JSONObject result = (JSONObject) res.get("result");

                        Gson gson = new Gson();
                        OutputMatchMaking op = gson.fromJson(result.toString(), OutputMatchMaking.class);
                        Log.d("OutputMatchMaking", op.toString());

                        //set data
                        tv_points.setText(op.getTotalPoint().toString() + "/" + 36);

                        //mangalik details
                        JSONObject bride = (JSONObject) res.get("bride_details");
                        Integer brideManglik = (Integer) bride.get("manglik_status");

                        if (brideManglik == 0) {
                            tv_maleMangal.setText(R.string.result_false);
                        } else {
                            tv_maleMangal.setText(R.string.result_true);
                        }


                        JSONObject groom = (JSONObject) res.get("bridegroom_details");
                        Integer groomManglik = (Integer) groom.get("manglik_status");

                        if (groomManglik == 0) {
                            tv_femaleMangal.setText(R.string.result_false);
                        } else {
                            tv_femaleMangal.setText(R.string.result_true);
                        }


                        //table data
                        tv_varnaObt.setText(op.getVarna().getPoint().toString());
                        tv_vashyaObt.setText(op.getVasya().getPoint().toString());
                        tv_taraObt.setText(op.getTara().getPoint().toString());
                        tv_yoniObt.setText(op.getYoni().getPoint().toString());
                        tv_maitriObt.setText(op.getGrahaMaitri().getPoint().toString());
                        tv_gunObt.setText(op.getGana().getPoint().toString());
                        tv_bhakatObt.setText(op.getBhakoot().getPoint().toString());
                        tv_nadiObt.setText(op.getNadi().getPoint().toString());
                        tv_totalObt.setText(op.getTotalPoint().toString());

                        List<String> gunReportList = op.getSubMessage();
                        tv_gunReport.setText("");
                        for (String gunReport : gunReportList) {
                            tv_gunReport.append(gunReport);
                        }

                        //To-DO
                        //each term defination using recycler


                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d(" MM onFailure", t.getMessage());
            }

        });
    }
}
