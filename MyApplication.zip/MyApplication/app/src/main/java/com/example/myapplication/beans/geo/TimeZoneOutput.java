package com.example.myapplication.beans.geo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TimeZoneOutput {

    @SerializedName("timezone")
    @Expose
    private Double timezone;

    public Double getTimezone() {
        return timezone;
    }

    public void setTimezone(Double timezone) {
        this.timezone = timezone;
    }

}