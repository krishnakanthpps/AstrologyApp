package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.numerology.NumerologyOutput;
import com.example.myapplication.services.astroapi.AstroAPIService;
import com.example.myapplication.services.astroapi.AstroApiRetrofitInstance;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Numerology extends AppCompatActivity {
    InputBirthDetails inputBirthDetails;
    TextView tv_date, tv_destinyNumber, tv_radicalNumber, tv_nameNumber, tv_favGod, tv_favDay, tv_favColor, tv_evilNumber;
    TextView tv_favSubstone, tv_favStone, tv_favMetal, tv_favMantra, tv_radicalRuler, tv_radicalNum, tv_neuralNum, tv_friendlyNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numerology);
        //input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        bindView();
        getNumeroTable();


    }

    public void bindView() {
        tv_date = (TextView) findViewById(R.id.tv_date);
        tv_destinyNumber = (TextView) findViewById(R.id.tv_destinyNumber);
        tv_radicalNumber = (TextView) findViewById(R.id.tv_radicalNum);
        tv_nameNumber = (TextView) findViewById(R.id.tv_nameNumber);
        tv_favGod = (TextView) findViewById(R.id.tv_favGod);
        tv_favDay = (TextView) findViewById(R.id.tv_favDay);
        tv_favColor = (TextView) findViewById(R.id.tv_favColor);
        tv_evilNumber = (TextView) findViewById(R.id.tv_evilNumber);


        tv_favSubstone = (TextView) findViewById(R.id.tv_favStone);
        tv_favStone = (TextView) findViewById(R.id.tv_favStone);
        tv_favMetal = (TextView) findViewById(R.id.tv_favMetal);
        tv_favMantra = (TextView) findViewById(R.id.tv_favMantra);
        tv_radicalRuler = (TextView) findViewById(R.id.tv_radicalRuler);
        tv_radicalNum = (TextView) findViewById(R.id.tv_radicalNum);
        tv_neuralNum = (TextView) findViewById(R.id.tv_neuralNum);
        tv_friendlyNum = (TextView) findViewById(R.id.tv_friendlyNum);


    }

    public void getNumeroTable() {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
//        SharedPreferences prefs= getSharedPreferences("Settings", Activity.MODE_PRIVATE);
//        String language = prefs.getString("my_lang","");
//        String lan =  "Accept-language: "+language;
//        System.out.println("********************"+lan);


        final Call<NumerologyOutput> call1 = apiService.getNumerologyOutput(ChangeLanguage.lang,inputBirthDetails);
        call1.enqueue(new Callback<NumerologyOutput>() {
            @Override
            public void onResponse(Call<NumerologyOutput> call, Response<NumerologyOutput> response) {
                if (response.isSuccessful()) {
                    NumerologyOutput numerologyOutput = (response.body());

                    System.out.println("res" + numerologyOutput);

                    //setting values
                    tv_date.setText(numerologyOutput.getDate());
                    tv_destinyNumber.setText(numerologyOutput.getDestinyNumber().toString());
                    tv_radicalNumber.setText(numerologyOutput.getRadicalNumber().toString());
                    tv_nameNumber.setText(numerologyOutput.getNameNumber().toString());
                    tv_favGod.setText(numerologyOutput.getFavGod());
                    tv_favDay.setText(numerologyOutput.getFavDay());
                    tv_favColor.setText(numerologyOutput.getFavColor());
                    tv_evilNumber.setText(numerologyOutput.getEvilNum());


                    tv_favSubstone.setText(numerologyOutput.getFavSubstone());
                    tv_favStone.setText(numerologyOutput.getFavStone());
                    tv_favMetal.setText(numerologyOutput.getFavMetal());
                    tv_favMantra.setText(numerologyOutput.getFavMantra());
                    tv_radicalRuler.setText(numerologyOutput.getRadicalRuler());
                    tv_radicalNum.setText(numerologyOutput.getRadicalNum());
                    tv_neuralNum.setText(numerologyOutput.getNeutralNum());
                    tv_friendlyNum.setText(numerologyOutput.getFriendlyNum());


                    Log.d("Numerology table", numerologyOutput.toString());
                }

            }

            @Override
            public void onFailure(Call<NumerologyOutput> call, Throwable t) {
//                flag =true;
                Log.d("Numero Table D. Failure", t.getMessage());

            }
        });
    }
}
