
package com.example.myapplication.beans.dosh.papasamaya;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("rahu_papa")
    @Expose
    private Integer rahuPapa;
    @SerializedName("sun_papa")
    @Expose
    private Double sunPapa;
    @SerializedName("saturn_papa")
    @Expose
    private Double saturnPapa;
    @SerializedName("mars_papa")
    @Expose
    private Integer marsPapa;

    public Integer getRahuPapa() {
        return rahuPapa;
    }

    public void setRahuPapa(Integer rahuPapa) {
        this.rahuPapa = rahuPapa;
    }

    public Double getSunPapa() {
        return sunPapa;
    }

    public void setSunPapa(Double sunPapa) {
        this.sunPapa = sunPapa;
    }

    public Double getSaturnPapa() {
        return saturnPapa;
    }

    public void setSaturnPapa(Double saturnPapa) {
        this.saturnPapa = saturnPapa;
    }

    public Integer getMarsPapa() {
        return marsPapa;
    }

    public void setMarsPapa(Integer marsPapa) {
        this.marsPapa = marsPapa;
    }

    @Override
    public String toString() {
        return "Response{" +
                "rahuPapa=" + rahuPapa +
                ", sunPapa=" + sunPapa +
                ", saturnPapa=" + saturnPapa +
                ", marsPapa=" + marsPapa +
                '}';
    }
}
