package com.example.myapplication;

import androidx.lifecycle.ViewModel;

public class MainMuhuratViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
