package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;


public class KundaliCheckActivity extends AppCompatActivity {
    private TextView displayDate ,displayTime;
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private EditText et_name;
    private String name;
    SimpleDateFormat timeformat;


    Button checkbtn;
    Calendar calendar ;
    LocalTime localTime;

    private static final String TAG = "KundaliCheckActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kundali_check);

        displayDate = (TextView)findViewById(R.id.date);
        displayTime = (TextView)findViewById(R.id.time);
        calendar = Calendar.getInstance();
        timeformat = new SimpleDateFormat("HH:mm");

        et_name = (EditText)findViewById(R.id.name);
        checkbtn = (Button)findViewById(R.id.checkbtn);

        checkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
            }
        });


        displayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        KundaliCheckActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
                updateTime();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "/"+ day + "/" + year);
                String date = month + "/"+ day + "/" + year;
                displayDate.setText(date);


            }
        };

        displayTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTime();
            }
        });

    }
    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);
            updateTime();
        }
    };
    public void updateTime() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }
    public void updateDate() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }

    public void chooseTime(){
        new TimePickerDialog(this , t ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
        String time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        displayTime.setText(time);
    }




    public void  check(){
        intialize();
        if(!validate()){
            Toast.makeText(this, "Failed to Process", Toast.LENGTH_SHORT).show();
        }else {
            toBeContinue();
        }
    }
    public void toBeContinue() {

    }
    public boolean validate(){
        boolean valid = true;
        if(name.isEmpty() || name.length()<=2){
            et_name.setError("Please enter valid name");
        }
        return valid;
    }
    public void intialize(){
        name = et_name.getText().toString().trim();

    }


}
