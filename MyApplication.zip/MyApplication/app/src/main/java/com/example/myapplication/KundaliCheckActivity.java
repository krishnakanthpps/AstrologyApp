package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.Geoname;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.services.ServicesAstroImpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Retrofit;

public class KundaliCheckActivity extends AppCompatActivity  {
    private TextView displayDate ,displayTime,displaySearch;
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private EditText et_name;
    private String name;
    SimpleDateFormat timeformat;
    Button checkbtn;
    Calendar calendar ;
    LocalTime localTime;
    Retrofit retrofit ;
    private Context context;
    private String location;
    AutoCompleteTextView et_location;
    static ServicesAstroImpl serv = new ServicesAstroImpl();
    static Geoname geoname;
    static boolean flag;
    static GeoDetails geoDetails;
    private Handler handler;
    static InputBirthDetails ip;
    private static final String TAG = "KundaliCheckActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kundali_check);

        setTitle("Birth Detail");
        displayDate = (TextView)findViewById(R.id.date);
        displayTime = (TextView)findViewById(R.id.time);
        calendar = Calendar.getInstance();
        timeformat = new SimpleDateFormat("HH:mm");
        et_name = (EditText)findViewById(R.id.name);
        checkbtn = (Button)findViewById(R.id.checkbtn);
        et_location = (AutoCompleteTextView)findViewById(R.id.et_location);
        displayTime.setText(timeformat.format(calendar.getTime()));
        displayDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));

        //Location

        checkbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i = new Intent(KundaliCheckActivity.this, Kundali.class);
               startActivity(i);
            }
        });
        displayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        KundaliCheckActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "-"+ day + "-" + year);
                String date = day + "-" + month + "-" + year;
                displayDate.setText(date);
            }
        };
        displayTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTime();
            }
        });
        //location
        et_location.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreData("mumbai");
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreData(et_location.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        et_location.setOnItemClickListener(onItemClickListener);
    }
    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);
            updateTime();
        }
    };
    public void updateTime() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }
    public void updateDate() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }
    public void chooseTime(){
        String time;
        new TimePickerDialog(this , t ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
//        if(calendar.get(Calendar.HOUR_OF_DAY) >= 0 && calendar.get(Calendar.HOUR_OF_DAY) < 12 ){
//            time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + "AM";
//        }else{
//            if (calendar.get(Calendar.HOUR_OF_DAY) == 12){
//                time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + "PM";
//            }else {
//                time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + "PM";
//            }
//        }
        time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        displayTime.setText(time);
    }
    public void  check(){
        intialize();
        if(!validate()){
            Toast.makeText(this, "Failed to Process", Toast.LENGTH_SHORT).show();
        }else {
            toBeContinue();
        }
    }
    public void toBeContinue() {
    }
    public boolean validate(){
        boolean valid = true;
        if(name.isEmpty() || name.length()<=2){
            et_name.setError("Please enter valid name");
        }
        return valid;
    }
    public void intialize(){
        name = et_name.getText().toString().trim();
    }
    private AdapterView.OnItemClickListener onItemClickListener =
            new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Toast.makeText(KundaliCheckActivity.this,
                            "Clicked item "
                                    + adapterView.getItemAtPosition(i)
                            , Toast.LENGTH_SHORT).show();
                }
            };
    public void getStoreData(final String strin){
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails  = serv.getgeodetails(in);
                flag=true;
            }
        }).start();

        if(flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName()+"/"+s.getCountryCode());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(KundaliCheckActivity.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));
            et_location.setAdapter(adapteo);
        }
    }
}
