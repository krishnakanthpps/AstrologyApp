package com.example.myapplication.beans.matchmaking.table;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InputMatchmaking {

    @SerializedName("ayanamsa")
    @Expose
    private String ayanamsa;
    @SerializedName("bride_dob")
    @Expose
    private String brideDob;
    @SerializedName("bridegroom_dob")
    @Expose
    private String bridegroomDob;
    @SerializedName("bride_coordinates")
    @Expose
    private String brideCoordinates;
    @SerializedName("bridegroom_coordinates")
    @Expose
    private String bridegroomCoordinates;
    @SerializedName("userid")
    @Expose
    private Integer userid;

    public String getAyanamsa() {
        return ayanamsa;
    }

    public void setAyanamsa(String ayanamsa) {
        this.ayanamsa = ayanamsa;
    }

    public String getBrideDob() {
        return brideDob;
    }

    public void setBrideDob(String brideDob) {
        this.brideDob = brideDob;
    }

    public String getBridegroomDob() {
        return bridegroomDob;
    }

    public void setBridegroomDob(String bridegroomDob) {
        this.bridegroomDob = bridegroomDob;
    }

    public String getBrideCoordinates() {
        return brideCoordinates;
    }

    public void setBrideCoordinates(String brideCoordinates) {
        this.brideCoordinates = brideCoordinates;
    }

    public String getBridegroomCoordinates() {
        return bridegroomCoordinates;
    }

    public void setBridegroomCoordinates(String bridegroomCoordinates) {
        this.bridegroomCoordinates = bridegroomCoordinates;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public InputMatchmaking() {
    }


    public InputMatchmaking(String ayanamsa, String brideDob, String bridegroomDob, String brideCoordinates,
                            String bridegroomCoordinates, Integer userid) {
        super();
        this.ayanamsa = ayanamsa;
        this.brideDob = brideDob;
        this.bridegroomDob = bridegroomDob;
        this.brideCoordinates = brideCoordinates;
        this.bridegroomCoordinates = bridegroomCoordinates;
        this.userid = userid;
    }

    @Override
    public String toString() {
        return "Input [ayanamsa=" + ayanamsa + ", brideDob=" + brideDob + ", bridegroomDob=" + bridegroomDob
                + ", brideCoordinates=" + brideCoordinates + ", bridegroomCoordinates=" + bridegroomCoordinates
                + ", userid=" + userid + "]";
    }


}