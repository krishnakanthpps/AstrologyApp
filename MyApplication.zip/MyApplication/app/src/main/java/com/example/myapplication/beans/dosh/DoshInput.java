package com.example.myapplication.beans.dosh;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DoshInput {

    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("tob")
    @Expose
    private String tob;
    @SerializedName("lat")
    @Expose
    private Double lat;
    @SerializedName("lon")
    @Expose
    private Double lon;
    @SerializedName("tz")
    @Expose
    private Double tz;
    @SerializedName("api_key")
    @Expose
    private String apiKey;

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getTob() {
        return tob;
    }

    public void setTob(String tob) {
        this.tob = tob;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public Double getTz() {
        return tz;
    }

    public void setTz(Double tz) {
        this.tz = tz;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public DoshInput() {
    }

    public DoshInput(String dob, String tob, Double lat, Double lon, Double tz, String apiKey) {
        this.dob = dob;
        this.tob = tob;
        this.lat = lat;
        this.lon = lon;
        this.tz = tz;
        this.apiKey = apiKey;
    }

    @Override
    public String toString() {
        return "DoshInput{" +
                "dob='" + dob + '\'' +
                ", tob='" + tob + '\'' +
                ", lat=" + lat +
                ", lon=" + lon +
                ", tz=" + tz +
                ", apiKey='" + apiKey + '\'' +
                '}';
    }
}