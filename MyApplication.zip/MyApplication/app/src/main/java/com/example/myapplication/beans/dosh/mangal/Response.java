
package com.example.myapplication.beans.dosh.mangal;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("factors")
    @Expose
    private Factors factors;
    @SerializedName("is_dosha_present")
    @Expose
    private Boolean isDoshaPresent;
    @SerializedName("bot_response")
    @Expose
    private String botResponse;
    @SerializedName("score")
    @Expose
    private Integer score;

    public Factors getFactors() {
        return factors;
    }

    public void setFactors(Factors factors) {
        this.factors = factors;
    }

    public Boolean getIsDoshaPresent() {
        return isDoshaPresent;
    }

    public void setIsDoshaPresent(Boolean isDoshaPresent) {
        this.isDoshaPresent = isDoshaPresent;
    }

    public String getBotResponse() {
        return botResponse;
    }

    public void setBotResponse(String botResponse) {
        this.botResponse = botResponse;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Response{" +
                "factors=" + factors +
                ", isDoshaPresent=" + isDoshaPresent +
                ", botResponse='" + botResponse + '\'' +
                ", score=" + score +
                '}';
    }
}
