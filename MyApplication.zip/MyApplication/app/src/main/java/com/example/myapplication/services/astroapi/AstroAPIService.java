package com.example.myapplication.services.astroapi;

import com.example.myapplication.beans.basicastro.BasicAstroDetail;
import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.birthdetails.OutputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.beans.geo.TimeZoneInput;
import com.example.myapplication.beans.geo.TimeZoneOutput;
import com.example.myapplication.beans.numerology.NumerologyOutput;
import com.example.myapplication.beans.panchang.BasicPanchang;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface AstroAPIService {
    final  String key = "Authorization: Basic NjEwODU5Ojg3N2Y0Mjk5YTBlNDNjOWE1NDA0NWM0ZjlkMjc1YTIz";

    @Headers({key})
    @POST("birth_details")
    Call<OutputBirthDetails> getBirthDetails(@Body InputBirthDetails birthDetails);

    @Headers({key})
    @POST("geo_details")
    Call<GeoDetails> getGenomes(@Body InputPlace inputPlace);

    @Headers({key})
    @POST("timezone")
    Call<TimeZoneOutput> getTimeZone(@Body TimeZoneInput timeZoneInput);

    @Headers({key})
    @POST("astro_details")
    Call<BasicAstroDetail> getAstroDetail(@Body InputBirthDetails birthDetails);

    @Headers({key})
    @POST("basic_panchang")
    Call<BasicPanchang> getBasicPanchang(@Header("Accept-language") String lan, @Body InputBirthDetails birthDetails);

    @Headers({key,"Accept-language: hi"})
    @POST("numero_table")
    Call<NumerologyOutput> getNumerologyOutput(@Header("Accept-language") String lan, @Body InputBirthDetails birthDetails);

}
