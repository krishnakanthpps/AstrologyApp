package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.birthdetails.OutputBirthDetails;
import com.example.myapplication.beans.panchang.BasicPanchang;
import com.example.myapplication.services.astroapi.AstroAPIService;
import com.example.myapplication.services.astroapi.AstroApiRetrofitInstance;
import com.example.myapplication.services.prokerala.CreateChart;
import com.example.myapplication.services.prokerala.ProkeralaAPIService;
import com.example.myapplication.services.prokerala.ProkeralaApiRetrofitInstance;

import org.json.JSONException;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Kundali extends AppCompatActivity {
    InputBirthDetails inputBirthDetails;

    //birth details
    TextView tv_name, tv_date, tv_time, tv_place, tv_longitude, tv_latitude, tv_timezone, tv_sunrise, tv_sunset, tv_ayanamsha;

    //panchang
    TextView tv_day, tv_tithi, tv_yog, tv_nakshatra, tv_karan, tv_sunrisePanchang, tv_sunsetPanchang;


    //chart
    //Lagna
    TextView tv_l1, tv_l2, tv_l3, tv_l4, tv_l5, tv_l6, tv_l7, tv_l8, tv_l9, tv_l10, tv_l11, tv_l12;
    //navamsha
    TextView tv_n1, tv_n2, tv_n3, tv_n4, tv_n5, tv_n6, tv_n7, tv_n8, tv_n9, tv_n10, tv_n11, tv_n12;
    //rashi
    TextView tv_r1, tv_r2, tv_r3, tv_r4, tv_r5, tv_r6, tv_r7, tv_r8, tv_r9, tv_r10, tv_r11, tv_r12;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kundali);

        //bind all view
        bindView();
        //Input
        inputBirthDetails= (InputBirthDetails) getIntent().getSerializableExtra("inputBirthDetails");
        System.out.println("kindali input"+inputBirthDetails);

        //get data
        getBirthDetails();
        getPanchang();
        getLagna();
        getNavamsha();
        getRashi();


    }

    public void bindView() {
        //birth details
        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_date = (TextView) findViewById(R.id.tv_date);
        tv_time = (TextView) findViewById(R.id.tv_time);
        tv_place = (TextView) findViewById(R.id.tv_place);
        tv_longitude = (TextView) findViewById(R.id.tv_longitude);
        tv_latitude = (TextView) findViewById(R.id.tv_latitude);
        tv_timezone = (TextView) findViewById(R.id.tv_timezone);
        tv_sunrise = (TextView) findViewById(R.id.tv_sunrise);
        tv_sunset = (TextView) findViewById(R.id.tv_sunset);
        tv_ayanamsha = (TextView) findViewById(R.id.tv_ayanamsha);

        //panchang
        tv_day = (TextView) findViewById(R.id.tv_day);
        tv_tithi = (TextView) findViewById(R.id.tv_tithi);
        tv_yog = (TextView) findViewById(R.id.tv_yog);
        tv_nakshatra = (TextView) findViewById(R.id.tv_nakshatra);
        tv_karan = (TextView) findViewById(R.id.tv_karan);
        tv_sunrisePanchang = (TextView) findViewById(R.id.tv_sunrisePanchang);
        tv_sunsetPanchang = (TextView) findViewById(R.id.tv_sunsetPanchang);


        //chart
        //lagna
        tv_l1 = (TextView) findViewById(R.id.tv_l1);
        tv_l2 = (TextView) findViewById(R.id.tv_l2);
        tv_l3 = (TextView) findViewById(R.id.tv_l3);
        tv_l4 = (TextView) findViewById(R.id.tv_l4);
        tv_l5 = (TextView) findViewById(R.id.tv_l5);
        tv_l6 = (TextView) findViewById(R.id.tv_l6);
        tv_l7 = (TextView) findViewById(R.id.tv_l7);
        tv_l8 = (TextView) findViewById(R.id.tv_l8);
        tv_l9 = (TextView) findViewById(R.id.tv_l9);
        tv_l10 = (TextView) findViewById(R.id.tv_l10);
        tv_l11 = (TextView) findViewById(R.id.tv_l11);
        tv_l12 = (TextView) findViewById(R.id.tv_l12);

        //navamsha
        tv_n1 = (TextView) findViewById(R.id.tv_n1);
        tv_n2 = (TextView) findViewById(R.id.tv_n2);
        tv_n3 = (TextView) findViewById(R.id.tv_n3);
        tv_n4 = (TextView) findViewById(R.id.tv_n4);
        tv_n5 = (TextView) findViewById(R.id.tv_n5);
        tv_n6 = (TextView) findViewById(R.id.tv_n6);
        tv_n7 = (TextView) findViewById(R.id.tv_n7);
        tv_n8 = (TextView) findViewById(R.id.tv_n8);
        tv_n9 = (TextView) findViewById(R.id.tv_n9);
        tv_n10 = (TextView) findViewById(R.id.tv_n10);
        tv_n11 = (TextView) findViewById(R.id.tv_n11);
        tv_n12 = (TextView) findViewById(R.id.tv_n12);

        //rashi
        tv_r1 = (TextView) findViewById(R.id.tv_r1);
        tv_r2 = (TextView) findViewById(R.id.tv_r2);
        tv_r3 = (TextView) findViewById(R.id.tv_r3);
        tv_r4 = (TextView) findViewById(R.id.tv_r4);
        tv_r5 = (TextView) findViewById(R.id.tv_r5);
        tv_r6 = (TextView) findViewById(R.id.tv_r6);
        tv_r7 = (TextView) findViewById(R.id.tv_r7);
        tv_r8 = (TextView) findViewById(R.id.tv_r8);
        tv_r9 = (TextView) findViewById(R.id.tv_r9);
        tv_r10 = (TextView) findViewById(R.id.tv_r10);
        tv_r11 = (TextView) findViewById(R.id.tv_r11);
        tv_r12 = (TextView) findViewById(R.id.tv_r12);

    }

    public void getBirthDetails() {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<OutputBirthDetails> call1 = apiService.getBirthDetails(inputBirthDetails);
        call1.enqueue(new Callback<OutputBirthDetails>() {
            @Override
            public void onResponse(Call<OutputBirthDetails> call, Response<OutputBirthDetails> response) {
                if (response.isSuccessful()) {
                    OutputBirthDetails outputBirthDetails = (response.body());
//                    tv_name.setText();
                    tv_date.setText(inputBirthDetails.getDay() + "-" + inputBirthDetails.getMonth() + "-" + inputBirthDetails.getYear());
                    tv_time.setText(inputBirthDetails.getHour() + ":" + inputBirthDetails.getMin());
//                    tv_place.setText();
                    tv_longitude.setText(inputBirthDetails.getLon().toString());
                    tv_latitude.setText(inputBirthDetails.getLat().toString());
                    tv_timezone.setText(inputBirthDetails.getTzone().toString());
                    tv_sunrise.setText(outputBirthDetails.getSunrise());
                    tv_sunset.setText(outputBirthDetails.getSunset());
                    tv_ayanamsha.setText(outputBirthDetails.getAyanamsha().toString());

//                   flag = true;
                    Log.d("Birth", outputBirthDetails.toString());
                }

            }

            @Override
            public void onFailure(Call<OutputBirthDetails> call, Throwable t) {
//                flag =true;
                Log.d("Birth D. Failure", t.getMessage());

            }
        });
    }

    public String getShortname(String name) {
        if (!name.isEmpty()) {
            name = name.toLowerCase();
            switch (name) {
                case "sun":
                    return getResources().getString(R.string.s_sun);
                case "moon":
                    return getResources().getString(R.string.s_moom);
                case "mercury":
                    return getResources().getString(R.string.s_mercury);
                case "venus":
                    return getResources().getString(R.string.s_venus);
                case "mars":
                    return getResources().getString(R.string.s_mars);
                case "jupiter":
                    return getResources().getString(R.string.s_jupiter);
                case "saturn":
                    return getResources().getString(R.string.s_saturn);
                case "rahu":
                    return getResources().getString(R.string.s_rahu);
                case "ketu":
                    return getResources().getString(R.string.s_ketu);
                case "ascendant":
                    return getResources().getString(R.string.s_ascedent);
            }
        }
        return "";
    }


    public void getLagna() {
        String datetime = inputBirthDetails.getYear() + "-" + inputBirthDetails.getMonth() + "-" + inputBirthDetails.getDay() + "T" + inputBirthDetails.getHour() + ":" + inputBirthDetails.getMin() + ":22Z";
        //coordinate
        String coordinate = inputBirthDetails.getLat() + "," + inputBirthDetails.getLon();

        ProkeralaAPIService apiService = ProkeralaApiRetrofitInstance.getApiService();
        final Call<ResponseBody> call1 = apiService.getPlanePosition("1", datetime, coordinate,
                "lagna");
        call1.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    String str = "";
                    try {
                        str = (response.body()).string();


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (!str.isEmpty()) {
                        CreateChart cc = new CreateChart();
                        try {
                            HashMap<Integer, List<String>> lagna = cc.getChart(str);
//                                    //set values
                            for (Integer val : lagna.keySet()) {
                                switch (val) {
                                    case 0:
                                        tv_l1.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l1.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 1:
                                        tv_l2.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l2.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 2:
                                        tv_l3.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l3.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 3:
                                        tv_l4.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l4.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 4:
                                        tv_l5.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l5.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 5:
                                        tv_l6.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l6.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 6:
                                        tv_l7.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l7.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 7:
                                        tv_l8.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l8.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 8:
                                        tv_l9.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l9.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 9:
                                        tv_l10.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l10.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 10:
                                        tv_l11.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l11.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 11:
                                        tv_l12.append(val + 1 + " ");
                                        for (String planet : lagna.get(val)) {
                                            tv_l12.append(getShortname(planet) + " ");
                                        }
                                        break;

                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                    Log.d("lagna", response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                flag =true;
                Log.d("lagna D. Failure", t.getMessage());

            }
        });
    }

    public void getNavamsha() {
        String datetime = inputBirthDetails.getYear() + "-" + inputBirthDetails.getMonth() + "-" + inputBirthDetails.getDay() + "T" + inputBirthDetails.getHour() + ":" + inputBirthDetails.getMin() + ":22Z";
        //coordinate
        String coordinate = inputBirthDetails.getLat() + "," + inputBirthDetails.getLon();

        ProkeralaAPIService apiService = ProkeralaApiRetrofitInstance.getApiService();
        final Call<ResponseBody> call1 = apiService.getPlanePosition("1", datetime, coordinate,
                "navamsa");
        call1.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    String str = "";
                    try {
                        str = (response.body()).string();


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (!str.isEmpty()) {
                        CreateChart cc = new CreateChart();
                        try {
                            HashMap<Integer, List<String>> navamsa = cc.getChart(str);
                            for (Integer val : navamsa.keySet()) {
                                switch (val) {
                                    case 0:
                                        tv_n1.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n1.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 1:
                                        tv_n2.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n2.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 2:
                                        tv_n3.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n3.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 3:
                                        tv_n4.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n4.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 4:
                                        tv_n5.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n5.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 5:
                                        tv_n6.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n6.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 6:
                                        tv_n7.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n7.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 7:
                                        tv_n8.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n8.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 8:
                                        tv_n9.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n9.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 9:
                                        tv_n10.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n10.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 10:
                                        tv_n11.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n11.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 11:
                                        tv_n12.append(val + 1 + " ");
                                        for (String planet : navamsa.get(val)) {
                                            tv_n12.append(getShortname(planet) + " ");
                                        }
                                        break;

                                }
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                    Log.d("BasicPanch", response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                flag =true;
                Log.d("BasicPanch D. Failure", t.getMessage());

            }
        });
    }

    public void getRashi() {

        String datetime = inputBirthDetails.getYear() + "-" + inputBirthDetails.getMonth() + "-" + inputBirthDetails.getDay() + "T" + inputBirthDetails.getHour() + ":" + inputBirthDetails.getMin() + ":22Z";
        //coordinate
        String coordinate = inputBirthDetails.getLat() + "," + inputBirthDetails.getLon();

        ProkeralaAPIService apiService = ProkeralaApiRetrofitInstance.getApiService();
        final Call<ResponseBody> call1 = apiService.getPlanePosition("1", datetime, coordinate,
                "rashi");
        call1.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    String str = "";
                    try {
                        str = (response.body()).string();


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (!str.isEmpty()) {

                        System.out.println("____________" + str);
                        CreateChart cc = new CreateChart();
                        try {
                            HashMap<Integer, List<String>> rashi = cc.getChart(str);

                            for (Integer val : rashi.keySet()) {
                                switch (val) {
                                    case 0:
                                        tv_r1.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r1.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 1:
                                        tv_r2.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r2.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 2:
                                        tv_r3.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r3.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 3:
                                        tv_r4.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r4.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 4:
                                        tv_r5.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r5.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 5:
                                        tv_r6.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r6.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 6:
                                        tv_r7.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r7.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 7:
                                        tv_r8.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r8.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 8:
                                        tv_r9.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r9.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 9:
                                        tv_r10.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r10.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 10:
                                        tv_r11.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r11.append(getShortname(planet) + " ");
                                        }
                                        break;
                                    case 11:
                                        tv_r12.append(val + 1 + " ");
                                        for (String planet : rashi.get(val)) {
                                            tv_r12.append(getShortname(planet) + " ");
                                        }
                                        break;

                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        Log.d("rashi", response.body().toString());
                    }
                }
            }


            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                flag =true;
                Log.d("rashi D. Failure", t.getMessage());

            }
        });

    }

    public void getPanchang() {

        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        //     ChangeLanguage cl = new ChangeLanguage();
//
//        SharedPreferences prefs= getSharedPreferences("Settings", Activity.MODE_PRIVATE);
//        String language = prefs.getString("my_lang","");
//        String lan =  "Accept-language: "+language;
//        System.out.println("********************"+lan);


        final Call<BasicPanchang> call1 = apiService.getBasicPanchang(ChangeLanguage.lang,inputBirthDetails);
        call1.enqueue(new Callback<BasicPanchang>() {
            @Override
            public void onResponse(Call<BasicPanchang> call, Response<BasicPanchang> response) {
                if (response.isSuccessful()) {
                    BasicPanchang bpan = (response.body());
                    tv_day.setText(bpan.getDay());
                    tv_tithi.setText(bpan.getTithi());
                    tv_yog.setText(bpan.getYog());
                    tv_nakshatra.setText(bpan.getNakshatra());
                    tv_karan.setText(bpan.getKaran());
                    tv_sunrisePanchang.setText(bpan.getSunrise());
                    tv_sunsetPanchang.setText(bpan.getSunset());


//                   flag = true;
                    Log.d("BasicPanch", response.body().toString());
                }

            }

            @Override
            public void onFailure(Call<BasicPanchang> call, Throwable t) {
//                flag =true;
                Log.d("BasicPanch D. Failure", t.getMessage());

            }
        });

    }

}
