package com.example.myapplication.services.vedicastroapi;


import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.dosh.DoshInput;

public class VedicInputFormatter {
    private String apiKey = "2966c315-103c-56b8-9242-8c956d37631f";

    public DoshInput getVedicInput(InputBirthDetails inputBirthDetails) {

        //conac 0 to time if less than 9
        String timeH = "";
        String timeM = "";
        if (inputBirthDetails.getHour() < 10) {
            timeH = "0" + timeH;
        }
        if (inputBirthDetails.getMin() < 10) {
            timeM = "0" + timeM;
        }

        DoshInput doshInput = new DoshInput();
        doshInput.setDob(
                inputBirthDetails.getDay().toString() + "/" +
                        inputBirthDetails.getMonth().toString() + "/" +
                        inputBirthDetails.getYear().toString()
        );
        doshInput.setTob(
                timeH + inputBirthDetails.getHour().toString() + ":" +
                        timeM + inputBirthDetails.getMin().toString()
        );
        doshInput.setLat(inputBirthDetails.getLat());
        doshInput.setLon(inputBirthDetails.getLon());
        doshInput.setTz(inputBirthDetails.getTzone());
        doshInput.setApiKey(apiKey);

        return doshInput;

    }
}
