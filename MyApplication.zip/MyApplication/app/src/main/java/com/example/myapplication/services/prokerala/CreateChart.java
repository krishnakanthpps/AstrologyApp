package com.example.myapplication.services.prokerala;

import com.example.myapplication.beans.kundali.Planet;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CreateChart {
    public HashMap getChart(String str) throws JSONException {
        JSONObject reqres = new JSONObject(str);

        JSONObject res = (JSONObject) reqres.get("response");
        System.out.println(res);

        JSONObject pp = (JSONObject) res.get("planet_positions");
        System.out.println(pp);


        // List<Planet> planetList = new ArrayList<>();

        HashMap<Integer, Planet> planetMap = new HashMap<>();
        // get all planet

        String ppStr = pp.toString();

        for (Integer i = 0; i <= 6; i++) {
            if (ppStr.contains(i.toString())) {

                JSONObject result = (JSONObject) pp.get(i.toString());

                Gson gson = new Gson();
                Planet planet = gson.fromJson(result.toString(), Planet.class);

                planetMap.put(planet.getId(), planet);

            }
        }

        for (Integer i = 100; i <= 102; i++) {
            if (ppStr.contains(i.toString())) {

                JSONObject result = (JSONObject) pp.get(i.toString());

                Gson gson = new Gson();
                Planet planet = gson.fromJson(result.toString(), Planet.class);

                // planetList.add(planet);
                planetMap.put(planet.getId(), planet);

            }
        }
        for (Integer ik : planetMap.keySet()) {
            System.out.println(ik + "-" + planetMap.get(ik).getName() + " " + planetMap.get(ik).getPosition());
        }
        System.out.println();


        HashMap<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
        for (Integer i = 0; i < 12; i++) {
            List<Integer> neList = new ArrayList<>();
            for (Integer ik : planetMap.keySet()) {
                if(i==planetMap.get(ik).getPosition()) {
                    neList.add(planetMap.get(ik).getId());
                }
            }
            map.put(i, neList);
        }

        System.out.println(map);

        HashMap<Integer, List<String>> finalHM = new HashMap<Integer, List<String>>();
        System.out.println("----------------------------------");
        for (Integer pos : map.keySet()) {
            // String mystr = "";
            List<Integer> pl = map.get(pos);

            List<String> planetName = new ArrayList<>();

            for (Integer ppl : pl) {
                // String name = planetMap.get(ppl).getName().substring(0,2);
                planetName.add(planetMap.get(ppl).getName());
            }
            finalHM.put(pos, planetName);
        }
        return finalHM;
    }
}
