package com.example.myapplication.services.prokerala;


import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface ProkeralaAPIService {
    String key = "Authorization: Bearer e56769488793cea2c47c14d37a27b539af3f1710ea5b9efeec9c8c145dd59230";

    @Headers({key})
    @GET("kundli-matching")
    Call<ResponseBody> getMatchingData(
            @Query("ayanamsa") String string,
            @Query("bride_dob") String bdob,
            @Query("bridegroom_dob") String bgobc,
            @Query("bride_coordinates") String bc,
            @Query("bridegroom_coordinates") String bgc
    );

    @Headers({key})
    @GET("planet-position")
    Call<ResponseBody> getPlanePosition(
            @Query("ayanamsa") String ayanamsa,
            @Query("datetime") String datetime,
            @Query("coordinates") String coordinates,
            @Query("chart_type") String chart_type
    );

}
