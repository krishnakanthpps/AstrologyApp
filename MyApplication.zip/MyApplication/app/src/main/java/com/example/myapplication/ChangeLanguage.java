package com.example.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ChangeLanguage extends AppCompatActivity {
    static String lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        setContentView(R.layout.activity_change_language);

        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        boolean firstStart = prefs.getBoolean("firstStart", true);

        //change to firstStart
        if (true) {
            chaangeLanguage();
            SharedPreferences pref = getSharedPreferences("prefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.putBoolean("firstStart", false);
            editor.apply();
        }else {
            Intent intent = new Intent(ChangeLanguage.this, Main2Activity.class);
            startActivity(intent);
        }
  }
    public void chaangeLanguage(){
        final String[] langList= {"English","हिन्दी","मराठी"};
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(ChangeLanguage.this);
        mBuilder.setTitle("Choose a Language");
        mBuilder.setSingleChoiceItems(langList, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if(i==0){
                    setLocale("en");
                    recreate();
                }else if(i==1){
                    setLocale("hi");
                    recreate();
                }else if(i==2){
                    setLocale("mr");
                    recreate();
                }
                dialog.dismiss();
                Intent intent = new Intent(ChangeLanguage.this,Main2Activity.class);
                startActivity(intent);

            }


        });
        AlertDialog mAlertDialog = mBuilder.create();
        mAlertDialog.show();

    }
    private void setLocale(String lang) {
        Locale locale  = new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale= locale;
        getBaseContext().getResources().updateConfiguration(configuration,getBaseContext().getResources().getDisplayMetrics());


        SharedPreferences.Editor editor = getSharedPreferences("Settings",MODE_PRIVATE).edit();
        editor.putString("my_lang",lang);
        editor.apply();



    }
    public void loadLocale(){
        SharedPreferences prefs= getSharedPreferences("Settings", Activity.MODE_PRIVATE);
        String language = prefs.getString("my_lang","");
        lang=language;
        setLocale(language);
    }
}
