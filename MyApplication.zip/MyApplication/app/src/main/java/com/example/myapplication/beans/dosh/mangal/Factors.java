
package com.example.myapplication.beans.dosh.mangal;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Factors {

    @SerializedName("moon")
    @Expose
    private String moon;
    @SerializedName("saturn")
    @Expose
    private String saturn;
    @SerializedName("rahu")
    @Expose
    private String rahu;

    public String getMoon() {
        return moon;
    }

    public void setMoon(String moon) {
        this.moon = moon;
    }

    public String getSaturn() {
        return saturn;
    }

    public void setSaturn(String saturn) {
        this.saturn = saturn;
    }

    public String getRahu() {
        return rahu;
    }

    public void setRahu(String rahu) {
        this.rahu = rahu;
    }

    @Override
    public String toString() {
        return "Factors{" +
                "moon='" + moon + '\'' +
                ", saturn='" + saturn + '\'' +
                ", rahu='" + rahu + '\'' +
                '}';
    }
}
