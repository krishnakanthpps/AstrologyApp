package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

public class MainDosh extends Fragment {

    private MainDoshViewModel mViewModel;

    public static MainDosh newInstance() {
        return new MainDosh();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.main_dosh_fragment, container, false);

        Button btn_kalarp = (Button) view.findViewById(R.id.btn_kalsarp);
        btn_kalarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kalsarpIntent = new Intent(getActivity(), UserProfile.class);
                kalsarpIntent.putExtra("className", "Kalsarp");
                startActivity(kalsarpIntent);
            }
        });

        Button btn_mangalDosh = (Button) view.findViewById(R.id.btn_mangalDosh);
        btn_mangalDosh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mangalDoshIntent = new Intent(getActivity(), UserProfile.class);
                mangalDoshIntent.putExtra("className", "MangalDosh");
                startActivity(mangalDoshIntent);
            }
        });

        Button btn_pitraDosh = (Button) view.findViewById(R.id.btn_pitraDosh);
        btn_pitraDosh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pitraIntent = new Intent(getActivity(), UserProfile.class);
                pitraIntent.putExtra("className", "PitraDosh");
                startActivity(pitraIntent);
            }
        });

        Button btn_papasamayamDosh = (Button) view.findViewById(R.id.btn_papasamayam);
        btn_papasamayamDosh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent papasamayamIntent = new Intent(getActivity(), UserProfile.class);
                papasamayamIntent.putExtra("className", "Papasamayam");
                startActivity(papasamayamIntent);
            }
        });
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainDoshViewModel.class);
        // TODO: Use the ViewModel
    }

}
