package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_kundali,btn_Match,btn_Punchanga,btn_KPSystem,btn_Varshapal,btn_AstroShop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_kundali = (Button)findViewById(R.id.buttonKundali);
        btn_Punchanga= (Button)findViewById(R.id.buttonPunchanga);
        btn_Varshapal=(Button)findViewById(R.id.buttonVarshapal);
        btn_Match= (Button)findViewById(R.id.buttonMatch);
        btn_KPSystem = (Button)findViewById(R.id.buttonKPSystem);
        btn_AstroShop = (Button)findViewById(R.id.buttonAstroShop);


        btn_kundali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kundaliIntent = new Intent(MainActivity.this,KundaliCheckActivity.class);
                startActivity(kundaliIntent);

            }
        });
        
        btn_Match.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent matchIntent = new Intent(MainActivity.this,Matching.class);
                startActivity(matchIntent);
            }
        });
            
        btn_Punchanga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Punchang Clicked", Toast.LENGTH_SHORT).show();
            }
        });
        
        btn_Varshapal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Varshapal Clicked", Toast.LENGTH_SHORT).show();
            }
        });
        
        btn_KPSystem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "KPSysrem Clicked", Toast.LENGTH_SHORT).show();
            }
        });
        
        btn_AstroShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Shopping Clicked", Toast.LENGTH_SHORT).show();
            }
        });




    }

}
