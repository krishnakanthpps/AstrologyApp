package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.agrawalsuneet.dotsloader.loaders.TrailingCircularDotsLoader;
import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.Geoname;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.beans.geo.TimeZoneInput;
import com.example.myapplication.beans.geo.TimeZoneOutput;
import com.example.myapplication.services.astroapi.AstroAPIService;
import com.example.myapplication.services.astroapi.AstroAPIServicesImpl;
import com.example.myapplication.services.astroapi.AstroApiRetrofitInstance;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class UserProfile extends AppCompatActivity {
    Retrofit retrofit;
    private Context context;

    //loading
    TrailingCircularDotsLoader lz;


    private TextView displayDate, displayTime;
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private EditText et_name;

    private String name;
    private String dob;
    private String time;
    private String location;

    private TextView tv_user;
    Calendar calendar;
    LocalTime localTime;
    SimpleDateFormat timeformat;
    AutoCompleteTextView et_location;
    Button btnAstroDetails;
    private Handler handler;

    public static InputBirthDetails inputBirthDetails = null;
    boolean isLocataionSelected = false;
    boolean flag1 = false;

    static AstroAPIServicesImpl serv = new AstroAPIServicesImpl();
    static Geoname geoname;
    static boolean flag;
    static GeoDetails geoDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        inputBirthDetails=null;

        lz = findViewById(R.id.lz);

        displayDate = (TextView) findViewById(R.id.date);
        displayTime = (TextView) findViewById(R.id.time);
        calendar = Calendar.getInstance();
        timeformat = new SimpleDateFormat("HH:mm");
        et_name = (EditText) findViewById(R.id.et_name);

//        tv_user = (TextView) findViewById(R.id.tv_user);

        btnAstroDetails = (Button) findViewById(R.id.bt_check);
        et_location = (AutoCompleteTextView) findViewById(R.id.et_location);
        btnAstroDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = et_name.getText().toString();
                dob = displayDate.getText().toString();
                time = displayTime.getText().toString();
                location = et_location.getText().toString();

                System.out.println("----------btn"+dob+time+location);

                if (inputBirthDetails == null) {
                    if(validate()){
                        lz.setVisibility(View.VISIBLE);
                        btnAstroDetails.setEnabled(false);
                        getInputBirthDetails(dob,time,location);
                    }
                } else {
                    redirect();
//                    tv_user.append(inputBirthDetails.toString());

                }
            }
        });

        displayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        UserProfile.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, dateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
                updateTime();
            }
        });

        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                String aM = "";
                String aD = "";

                month = month + 1;

                if (month < 10) {
                    aM = "0";
                }
                if (day < 10) {
                    aD = "0";
                }
                String date = aD + day + "/" + aM + month + "/" + year;
                displayDate.setText(date);
            }
        };

        displayTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTime();
            }
        });
        et_location.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreData("mumbai");
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreData(et_location.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        et_location.setOnItemClickListener(onItemClickListener);

    }

    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);
            updateTime();
        }
    };

    public void updateTime() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }

    public void updateDate() {
        displayTime.setText(timeformat.format(calendar.getTime()));
    }

    public void chooseTime() {
        new TimePickerDialog(this, t, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
        String time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        displayTime.setText(time);
    }


    public void check() {
        intialize();
        if (!validate()) {
            Toast.makeText(this, "Failed to Process", Toast.LENGTH_SHORT).show();
        } else {
            toBeContinue();
        }
    }

    public void toBeContinue() {
    }

    public boolean validate() {
        boolean valid = true;
        if (name.isEmpty() || name.length() <= 2) {
            et_name.setError("Please enter valid name");
            valid=false;
        }
        if(location.isEmpty() || !isLocataionSelected){
            et_location.setError("Please select a date");
            valid=false;
        }
        return valid;
    }

    public void intialize() {
        name = et_name.getText().toString().trim();

    }

    private AdapterView.OnItemClickListener onItemClickListener =
            new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    isLocataionSelected=true;
                }
            };

    public void getStoreData(final String strin) {
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails = serv.getgeodetails(in);
                flag = true;
            }
        }).start();
           if (flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(UserProfile.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));
            et_location.setAdapter(adapteo);
        }
    }

    public void redirect() {
//        tv_user.append(inputBirthDetails.toString());
        String className = getIntent().getExtras().getString("className");
        if (className.equals("Kundali")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, Kundali.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        } else if (className.equals("Numerology")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, Numerology.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        }
        else if (className.equals("Kalsarp")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, Kalsarp.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        }
        else if (className.equals("MangalDosh")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, MangalDosh.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        }
        else if (className.equals("PitraDosh")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, PitraDosh.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        }
        else if (className.equals("Papasamayam")) {
            System.out.println("redirecting" + inputBirthDetails);
            Intent i = new Intent(UserProfile.this, Papasamayam.class);
            i.putExtra("inputBirthDetails", inputBirthDetails);
            startActivity(i);
        }


    }
    public void getInputBirthDetails(String date,String time,String location){
        inputBirthDetails = new InputBirthDetails();

        //call geo detail
        InputPlace iplace = new InputPlace();
        iplace.setPlace(location);
        iplace.setMaxRows(1);
        getgeodetails(iplace);

        System.out.println("-----------getInp"+dob+time+location);
        // dd/mm/yyyy
        String[] dateArray = date.split("/");
        //day
        inputBirthDetails.setDay(Integer.parseInt(dateArray[0]));

        //month
        inputBirthDetails.setMonth(Integer.parseInt(dateArray[1]));

        //year
        inputBirthDetails.setYear(Integer.parseInt(dateArray[2]));

        //time

        String[] timeArray = time.split(":");
        //hour
        inputBirthDetails.setHour(Integer.parseInt(timeArray[0]));

        //min
        inputBirthDetails.setMin(Integer.parseInt(timeArray[1]));

    }

    //create
    public void getgeodetails(InputPlace iplace) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<GeoDetails> call1 = apiService.getGenomes(iplace);
        call1.enqueue(new Callback<GeoDetails>() {
            @Override
            public void onResponse(Call<GeoDetails> call, Response<GeoDetails> response) {
                if (response.isSuccessful()) {
                    GeoDetails geoDeatils = response.body();
                    List<Geoname> geonameList   = geoDeatils.getGeonames();
                    Geoname geoname = geonameList.get(0);
                    TimeZoneInput tzin = new TimeZoneInput();
                    tzin.setCountryCode(geoname.getTimezoneId());
                    tzin.setIsDst("true");
                    getTimeZone(tzin);
                    inputBirthDetails.setLat(Double.parseDouble(geoname.getLatitude()));
                    inputBirthDetails.setLon(Double.parseDouble(geoname.getLongitude()));
                    System.out.println("-----------geode"+geoname);

                }

            }

            @Override
            public void onFailure(Call<GeoDetails> call, Throwable t) {
                System.out.println(t.getMessage());

            }
        });
    }
       public void getTimeZone(TimeZoneInput tzi) {
        AstroAPIService apiService = AstroApiRetrofitInstance.getApiService();
        final Call<TimeZoneOutput> call1 = apiService.getTimeZone(tzi);
        call1.enqueue(new Callback<TimeZoneOutput>() {
            @Override
            public void onResponse(Call<TimeZoneOutput> call, Response<TimeZoneOutput> response) {
                if (response.isSuccessful()) {
                    TimeZoneOutput tzout = response.body();
                    System.out.println(tzout);
                    inputBirthDetails.setTzone(tzout.getTimezone());
                    System.out.println("----------Time"+dob+time+location);
                    redirect();
                }
            }
            @Override
            public void onFailure(Call<TimeZoneOutput> call, Throwable t) {
                System.err.println(t.getMessage());
            }
        });
    }


}
