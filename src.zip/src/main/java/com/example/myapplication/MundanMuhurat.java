package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class MundanMuhurat extends AppCompatActivity {


    PDFView pdfView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mundan_muhurat);


        setTitle("Mundan Muhurat 2020");

        pdfView = (PDFView)findViewById(R.id.pdf_mundanMuhurat);
        pdfView.fromAsset("MundanMuhurat(English).pdf").load();

    }
}
