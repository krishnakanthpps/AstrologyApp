package com.example.myapplication;

import androidx.lifecycle.ViewModel;

public class MainDoshViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
