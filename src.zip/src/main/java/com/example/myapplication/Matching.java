package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.myapplication.beans.birthdetails.InputBirthDetails;
import com.example.myapplication.beans.geo.GeoDetails;
import com.example.myapplication.beans.geo.Geoname;
import com.example.myapplication.beans.geo.InputPlace;
import com.example.myapplication.services.ServicesAstroImpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Matching extends AppCompatActivity {

    Button btn_show;
    TextView maleName,femaleName,maleDate,femaleDate,maleTime,femaleTime;
    AutoCompleteTextView maleLocation,femaleLocation;
    SimpleDateFormat timeformat;
    Calendar calendar ;
    private DatePickerDialog.OnDateSetListener dateSetListenerMale ,dateSetListenerFemale ;
    private static final String TAG = "Matching";


    static ServicesAstroImpl serv = new ServicesAstroImpl();
    static Geoname geoname;
    static boolean flag;
    static GeoDetails geoDetails;
    private Handler handler;
    static InputBirthDetails ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matching);

        btn_show = (Button)findViewById(R.id.btn_showMatch);
        maleName = (TextView)findViewById(R.id.tv_maleName);
        femaleName = (TextView)findViewById(R.id.tv_femaleName);
        maleDate = (TextView)findViewById(R.id.tv_maleDate);
        femaleDate = (TextView)findViewById(R.id.tv_femaleDate);
        maleTime = (TextView)findViewById(R.id.tv_maleTime);
        femaleTime = (TextView)findViewById(R.id.tv_femaleTime);
        maleLocation = (AutoCompleteTextView)findViewById(R.id.et_maleLocation);
        femaleLocation = (AutoCompleteTextView)findViewById(R.id.et_femaleLocation);

//        male
        maleTime.setText(timeformat.format(calendar.getTime()));
        maleDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));
//female
        femaleTime.setText(timeformat.format(calendar.getTime()));
        femaleDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));

        setTitle("Matching");

        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Matching.this,MatchingData.class);
                startActivity(i);
            }
        });
//        male
        maleDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Matching.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListenerMale,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        dateSetListenerMale = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "-"+ day + "-" + year);
                String date = day + "-" + month + "-" + year;
                maleDate.setText(date);
            }
        };
        maleTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTimeMale();
            }
        });


//       female

        femaleDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Matching.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListenerFemale,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        dateSetListenerFemale = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG,"onDateSet: mm/dd/yyy:" + month + "-"+ day + "-" + year);
                String date = day + "-" + month + "-" + year;
                maleDate.setText(date);
            }
        };
        femaleTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseTimeFemale();
            }
        });


 //      Location male

        maleLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreDataMale("mumbai");
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreDataMale(maleLocation.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        //location female
            femaleLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                getStoreDataFemale("mumbai");
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getStoreDataFemale(femaleLocation.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        femaleLocation.setOnItemClickListener(onItemClickListener);
        maleLocation.setOnItemClickListener(onItemClickListener);
    }







//      button

    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);
            updateTimeFemale();
        }
    };
    TimePickerDialog.OnTimeSetListener t1 = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);
            updateTimeMale();
        }
    };


    public void updateTimeFemale() {

        femaleTime.setText(timeformat.format(calendar.getTime()));
    }
    public void updateTimeMale() {
        maleTime.setText(timeformat.format(calendar.getTime()));
    }

    private AdapterView.OnItemClickListener onItemClickListener =
            new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Toast.makeText(Matching.this,
                            "Clicked item "
                                    + adapterView.getItemAtPosition(i)
                            , Toast.LENGTH_SHORT).show();
                }
            };

    public void chooseTimeMale(){
        String time;
        new TimePickerDialog(this , t ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
        time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        maleTime.setText(time);

    }
    public void chooseTimeFemale(){
        String time;
        new TimePickerDialog(this , t1 ,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true).show();
        time = calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE);
        maleTime.setText(time);
    }


    public void getStoreDataFemale(final String strin){
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails  = serv.getgeodetails(in);
                flag=true;
            }
        }).start();

        if(flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName()+"/"+s.getCountryCode());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(Matching.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));

            femaleLocation.setAdapter(adapteo);
        }

    }


    public void getStoreDataMale(final String strin) {
        InputPlace in = new InputPlace();
        in.setPlace(strin);
        in.setMaxRows(5);
        new Thread(new Runnable() {
            public void run() {
                InputPlace in = new InputPlace();
                in.setPlace(strin);
                in.setMaxRows(5);
                geoDetails = serv.getgeodetails(in);
                flag = true;
            }
        }).start();

        if (flag) {
            List<String> str = new ArrayList<String>();
            for (Geoname s : geoDetails.getGeonames()) {
                str.add(s.getPlaceName() + "/" + s.getCountryCode());
            }
            ArrayAdapter<String> adapteo = new ArrayAdapter<String>(Matching.this,
                    android.R.layout.simple_dropdown_item_1line, str.toArray(new String[0]));
            maleLocation.setAdapter(adapteo);

        }
    }

}
