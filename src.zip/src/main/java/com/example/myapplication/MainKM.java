package com.example.myapplication;

import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class MainKM extends Fragment {

    private MainKMViewModel mViewModel;
    Button btn_kundali,btn_Match,btn_Punchanga,btn_KPSystem,btn_Varshapal,btn_AstroShop;
    public static MainKM newInstance() {
        return new MainKM();
    }



    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view=  inflater.inflate(R.layout.main_k_m_fragment, container, false);
        Button btn_kundali = (Button)view.findViewById(R.id.buttonKundali);
        btn_kundali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kundaliIntent = new Intent(getActivity(),KundaliCheckActivity.class);
                startActivity(kundaliIntent);
            }
        });

        Button btn_matching = (Button)view.findViewById(R.id.buttonMatch);
        btn_matching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent matchIntent = new Intent(getActivity(),Matching.class);
                startActivity(matchIntent);
            }
        });



        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(MainKMViewModel.class);


        // TODO: Use the ViewModel
    }

}
