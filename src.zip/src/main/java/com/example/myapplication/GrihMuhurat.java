package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class GrihMuhurat extends AppCompatActivity {

    PDFView grihMuhurat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grih_muhurat);

        setTitle("Griha Pravesh Muhurat 2020");

        grihMuhurat = (PDFView)findViewById(R.id.pdf_grihMuhurat);
        grihMuhurat.fromAsset("GrihPraveshMuhurat(English).pdf").load();

    }
}
