package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Kundali extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kundali);
    }
    public void bindView(){

    }
    public void getLagna(){

    }
    public void getNavamsha(){

    }
    public void getMoon(){

    }
    public void getChalit(){

    }
    public void getPlanets(){

    }
    public void getBirthDetails(){

    }
    public void getPanchang(){

    }
}
