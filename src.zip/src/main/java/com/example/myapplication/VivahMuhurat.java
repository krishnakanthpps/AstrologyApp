package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class VivahMuhurat extends AppCompatActivity {

    PDFView vivahMuhurat;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vivah_muhurat);

        setTitle("Vivah Muhurat 2020");

        vivahMuhurat = (PDFView)findViewById(R.id.pdf_vivahMuhurat);
        vivahMuhurat.fromAsset("VivahMuhurat(English).pdf").load();

    }
}
